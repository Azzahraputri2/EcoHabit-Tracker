package com.example.ecohabit1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.DialogInterface;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class AddHabitActivity extends AppCompatActivity {

    private TextView txtTarget;
    private EditText edtHabitName;
    private TextView btnDaily, btnWeekly, btnMonthly, btnYearly;
    private TextView catWaste, catWater, catEnergy, catFood, catTransport, catShopping;
    private AppCompatButton btnSave, btnCancel;
    private ImageView btnBack, btnMinus, btnPlus;
    private Switch switchReminder;

    // Dynamic containers untuk multiple reminders
    private LinearLayout layoutDailyTimes;
    private LinearLayout layoutWeeklyDays;
    private LinearLayout layoutMonthlyDates;
    private LinearLayout layoutYearlyDates;

    // Time inputs untuk weekly, monthly, yearly
    private EditText edtHourWeekly, edtMinuteWeekly;
    private EditText edtHourMonthly, edtMinuteMonthly;
    private EditText edtHourYearly, edtMinuteYearly;

    // Lists untuk menyimpan reminder items
    private List<View> dailyTimeItems = new ArrayList<>();
    private List<View> weeklyDayItems = new ArrayList<>();
    private List<View> monthlyDateItems = new ArrayList<>();
    private List<View> yearlyDateItems = new ArrayList<>();

    private int target = 0;
    private String selectedFrequency = "daily";
    private String selectedCategory = "";
    private boolean isReminderEnabled = false;

    // Data untuk multiple reminders
    private List<String> dailyTimes = new ArrayList<>();
    private List<String> weeklyDays = new ArrayList<>();
    private List<String> monthlyDates = new ArrayList<>();
    private List<String> yearlyMonths = new ArrayList<>();
    private List<String> yearlyDates = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Toast.makeText(this, "AddHabitActivity dibuka!", Toast.LENGTH_SHORT).show();

        try {
            setContentView(R.layout.activity_add_habit);
            initializeViews();
            setupClickListeners();
            setupFrequencySelection();
            setupCategorySelection();
            setupReminderSwitch();
            setupFooter();

            // Set initial frequency selection
            updateFrequencyUI(btnDaily);
            // Set initial reminder visibility
            updateReminderUI();

        } catch (Exception e) {
            Toast.makeText(this, "Error di AddHabit: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
            finish();
        }
    }

    private void initializeViews() {
        try {
            // Back button
            btnBack = findViewById(R.id.btnBack);

            // Habit name
            edtHabitName = findViewById(R.id.edtHabitName);

            // Frequency buttons
            btnDaily = findViewById(R.id.btnDaily);
            btnWeekly = findViewById(R.id.btnWeekly);
            btnMonthly = findViewById(R.id.btnMonthly);
            btnYearly = findViewById(R.id.btnYearly);

            // Target controls
            btnMinus = findViewById(R.id.btnMinus);
            btnPlus = findViewById(R.id.btnPlus);
            txtTarget = findViewById(R.id.txtTarget);
            updateTargetDisplay();

            // Category buttons
            catWaste = findViewById(R.id.catWaste);
            catWater = findViewById(R.id.catWater);
            catEnergy = findViewById(R.id.catEnergy);
            catFood = findViewById(R.id.catFood);
            catTransport = findViewById(R.id.catTransport);
            catShopping = findViewById(R.id.catShopping);

            // Reminder controls
            switchReminder = findViewById(R.id.switchReminder);

            // Dynamic containers
            layoutDailyTimes = findViewById(R.id.layoutDailyTimes);
            layoutWeeklyDays = findViewById(R.id.layoutWeeklyDays);
            layoutMonthlyDates = findViewById(R.id.layoutMonthlyDates);
            layoutYearlyDates = findViewById(R.id.layoutYearlyDates);

            // Time inputs untuk weekly, monthly, yearly
            edtHourWeekly = findViewById(R.id.edtHourWeekly);
            edtMinuteWeekly = findViewById(R.id.edtMinuteWeekly);
            edtHourMonthly = findViewById(R.id.edtHourMonthly);
            edtMinuteMonthly = findViewById(R.id.edtMinuteMonthly);
            edtHourYearly = findViewById(R.id.edtHourYearly);
            edtMinuteYearly = findViewById(R.id.edtMinuteYearly);

            // Action buttons
            btnSave = findViewById(R.id.btnSave);
            btnCancel = findViewById(R.id.btnCancel);

            Toast.makeText(this, "Semua view berhasil di-load!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error initializeViews: " + e.getMessage(), Toast.LENGTH_LONG).show();
            throw e;
        }
    }

    private void setupClickListeners() {
        // Back button - Kembali ke MainActivity
        btnBack.setOnClickListener(v -> {
            showCancelConfirmation();
        });

        // Target controls
        btnMinus.setOnClickListener(v -> decreaseTarget());
        btnPlus.setOnClickListener(v -> increaseTarget());

        // Cancel button - Kembali ke MainActivity
        btnCancel.setOnClickListener(v -> {
            showCancelConfirmation();
        });

        // Save button
        btnSave.setOnClickListener(v -> saveHabit());
    }

    private void showCancelConfirmation() {
        if (hasUnsavedChanges()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Cancel Creating Habit");
            builder.setMessage("Are you sure you want to cancel? Any unsaved changes will be lost.");

            builder.setNegativeButton("No, Continue", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            builder.setPositiveButton("Yes, Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    navigateToMainActivity();
                }
            });

            AlertDialog dialog = builder.create();
            dialog.show();

            // Customize button colors
            Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

            negativeButton.setTextColor(ContextCompat.getColor(this, R.color.text_gray));
            positiveButton.setTextColor(ContextCompat.getColor(this, R.color.delete_red));
        } else {
            navigateToMainActivity();
        }
    }

    private boolean hasUnsavedChanges() {
        return !TextUtils.isEmpty(edtHabitName.getText().toString().trim()) ||
                target > 0 ||
                !TextUtils.isEmpty(selectedCategory) ||
                !TextUtils.isEmpty(edtHourWeekly.getText().toString().trim()) ||
                !TextUtils.isEmpty(edtMinuteWeekly.getText().toString().trim()) ||
                !TextUtils.isEmpty(edtHourMonthly.getText().toString().trim()) ||
                !TextUtils.isEmpty(edtMinuteMonthly.getText().toString().trim()) ||
                !TextUtils.isEmpty(edtHourYearly.getText().toString().trim()) ||
                !TextUtils.isEmpty(edtMinuteYearly.getText().toString().trim()) ||
                !dailyTimes.isEmpty() || !weeklyDays.isEmpty() ||
                !monthlyDates.isEmpty() || !yearlyMonths.isEmpty();
    }

    private void setupReminderSwitch() {
        switchReminder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isReminderEnabled = isChecked;
                updateReminderUI();
            }
        });
    }

    private void updateReminderUI() {
        if (!isReminderEnabled) {
            clearAllReminderItems();
            hideAllReminderSections();
            return;
        }

        showReminderSectionForFrequency();

        switch (selectedFrequency) {
            case "daily":
                setupDailyReminders();
                break;
            case "weekly":
                setupWeeklyReminders();
                break;
            case "monthly":
                setupMonthlyReminders();
                break;
            case "yearly":
                setupYearlyReminders();
                break;
        }
    }

    private void showReminderSectionForFrequency() {
        hideAllReminderSections();

        if (!isReminderEnabled) return;

        switch (selectedFrequency) {
            case "daily":
                findViewById(R.id.layoutDaily).setVisibility(View.VISIBLE);
                break;
            case "weekly":
                findViewById(R.id.layoutWeekly).setVisibility(View.VISIBLE);
                findViewById(R.id.layoutTimeWeekly).setVisibility(View.VISIBLE);
                break;
            case "monthly":
                findViewById(R.id.layoutMonthly).setVisibility(View.VISIBLE);
                findViewById(R.id.layoutTimeMonthly).setVisibility(View.VISIBLE);
                break;
            case "yearly":
                findViewById(R.id.layoutYearly).setVisibility(View.VISIBLE);
                findViewById(R.id.layoutTimeYearly).setVisibility(View.VISIBLE);
                break;
        }
    }

    private void hideAllReminderSections() {
        findViewById(R.id.layoutDaily).setVisibility(View.GONE);
        findViewById(R.id.layoutWeekly).setVisibility(View.GONE);
        findViewById(R.id.layoutMonthly).setVisibility(View.GONE);
        findViewById(R.id.layoutYearly).setVisibility(View.GONE);

        findViewById(R.id.layoutTimeWeekly).setVisibility(View.GONE);
        findViewById(R.id.layoutTimeMonthly).setVisibility(View.GONE);
        findViewById(R.id.layoutTimeYearly).setVisibility(View.GONE);
    }

    private void setupDailyReminders() {
        clearAllReminderItems();
        layoutDailyTimes.removeAllViews();
        dailyTimeItems.clear();
        dailyTimes.clear();

        for (int i = 0; i < target; i++) {
            View timeItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_daily, layoutDailyTimes, false);

            TextView label = timeItem.findViewById(R.id.textTimeLabel);
            if (label != null) {
                label.setText("Time " + (i + 1) + " :");
            }

            EditText hourInput = timeItem.findViewById(R.id.edtHour);
            EditText minuteInput = timeItem.findViewById(R.id.edtMinute);

            final int index = i;
            hourInput.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    saveDailyTime(index, hourInput.getText().toString(), minuteInput.getText().toString());
                }
            });

            minuteInput.setOnFocusChangeListener((v, hasFocus) -> {
                if (!hasFocus) {
                    saveDailyTime(index, hourInput.getText().toString(), minuteInput.getText().toString());
                }
            });

            layoutDailyTimes.addView(timeItem);
            dailyTimeItems.add(timeItem);
            dailyTimes.add("");
        }
    }

    private void saveDailyTime(int index, String hour, String minute) {
        if (index < dailyTimes.size()) {
            String time = formatTime(hour, minute);
            dailyTimes.set(index, time);
        }
    }

    private void setupWeeklyReminders() {
        clearAllReminderItems();
        layoutWeeklyDays.removeAllViews();
        weeklyDayItems.clear();
        weeklyDays.clear();

        for (int i = 0; i < target; i++) {
            View dayItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_weekly, layoutWeeklyDays, false);

            TextView label = dayItem.findViewById(R.id.textDayLabel);
            if (label != null) {
                label.setText("Day " + (i + 1) + " :");
            }

            Spinner daySpinner = dayItem.findViewById(R.id.spinnerDay);
            setupDaySpinner(daySpinner, i);

            layoutWeeklyDays.addView(dayItem);
            weeklyDayItems.add(dayItem);
            weeklyDays.add("Monday");
        }
    }

    private void setupMonthlyReminders() {
        clearAllReminderItems();
        layoutMonthlyDates.removeAllViews();
        monthlyDateItems.clear();
        monthlyDates.clear();

        for (int i = 0; i < target; i++) {
            View dateItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_monthly, layoutMonthlyDates, false);

            TextView label = dateItem.findViewById(R.id.textDateLabel);
            if (label != null) {
                label.setText("Date " + (i + 1) + " :");
            }

            Spinner dateSpinner = dateItem.findViewById(R.id.spinnerDate);
            setupMonthlyDateSpinner(dateSpinner, i);

            layoutMonthlyDates.addView(dateItem);
            monthlyDateItems.add(dateItem);
            monthlyDates.add("1");
        }
    }

    private void setupYearlyReminders() {
        clearAllReminderItems();
        layoutYearlyDates.removeAllViews();
        yearlyDateItems.clear();
        yearlyMonths.clear();
        yearlyDates.clear();

        for (int i = 0; i < target; i++) {
            View yearlyItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_yearly, layoutYearlyDates, false);

            Spinner monthSpinner = yearlyItem.findViewById(R.id.spinnerMonth);
            Spinner dateSpinner = yearlyItem.findViewById(R.id.spinnerDate);

            setupYearlyMonthSpinner(monthSpinner, i);
            setupYearlyDateSpinner(dateSpinner, i);

            layoutYearlyDates.addView(yearlyItem);
            yearlyDateItems.add(yearlyItem);
            yearlyMonths.add("January");
            yearlyDates.add("1");
        }
    }

    private void clearAllReminderItems() {
        layoutDailyTimes.removeAllViews();
        layoutWeeklyDays.removeAllViews();
        layoutMonthlyDates.removeAllViews();
        layoutYearlyDates.removeAllViews();

        dailyTimeItems.clear();
        weeklyDayItems.clear();
        monthlyDateItems.clear();
        yearlyDateItems.clear();

        dailyTimes.clear();
        weeklyDays.clear();
        monthlyDates.clear();
        yearlyMonths.clear();
        yearlyDates.clear();
    }

    private void setupDaySpinner(Spinner spinner, final int index) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.days_of_week,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (index < weeklyDays.size()) {
                    weeklyDays.set(index, parent.getItemAtPosition(position).toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                if (index < weeklyDays.size()) {
                    weeklyDays.set(index, "Monday");
                }
            }
        });
    }

    private void setupMonthlyDateSpinner(Spinner spinner, final int index) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.monthly_dates,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (index < monthlyDates.size()) {
                    monthlyDates.set(index, parent.getItemAtPosition(position).toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                if (index < monthlyDates.size()) {
                    monthlyDates.set(index, "1");
                }
            }
        });
    }

    private void setupYearlyMonthSpinner(Spinner spinner, final int index) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.months_of_year,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (index < yearlyMonths.size()) {
                    yearlyMonths.set(index, parent.getItemAtPosition(position).toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                if (index < yearlyMonths.size()) {
                    yearlyMonths.set(index, "January");
                }
            }
        });
    }

    private void setupYearlyDateSpinner(Spinner spinner, final int index) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.monthly_dates,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (index < yearlyDates.size()) {
                    yearlyDates.set(index, parent.getItemAtPosition(position).toString());
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                if (index < yearlyDates.size()) {
                    yearlyDates.set(index, "1");
                }
            }
        });
    }

    private void setupFrequencySelection() {
        View.OnClickListener frequencyListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateFrequencyUI((TextView) v);

                if (v.getId() == R.id.btnDaily) {
                    selectedFrequency = "daily";
                } else if (v.getId() == R.id.btnWeekly) {
                    selectedFrequency = "weekly";
                } else if (v.getId() == R.id.btnMonthly) {
                    selectedFrequency = "monthly";
                } else if (v.getId() == R.id.btnYearly) {
                    selectedFrequency = "yearly";
                }

                updateReminderUI();
            }
        };

        btnDaily.setOnClickListener(frequencyListener);
        btnWeekly.setOnClickListener(frequencyListener);
        btnMonthly.setOnClickListener(frequencyListener);
        btnYearly.setOnClickListener(frequencyListener);
    }

    private void updateFrequencyUI(TextView selectedView) {
        btnDaily.setBackgroundResource(R.drawable.bg_frequency_unselected);
        btnWeekly.setBackgroundResource(R.drawable.bg_frequency_unselected);
        btnMonthly.setBackgroundResource(R.drawable.bg_frequency_unselected);
        btnYearly.setBackgroundResource(R.drawable.bg_frequency_unselected);

        btnDaily.setTextColor(getResources().getColor(R.color.text_gray));
        btnWeekly.setTextColor(getResources().getColor(R.color.text_gray));
        btnMonthly.setTextColor(getResources().getColor(R.color.text_gray));
        btnYearly.setTextColor(getResources().getColor(R.color.text_gray));

        selectedView.setBackgroundResource(R.drawable.bg_frequency_selected);
        selectedView.setTextColor(getResources().getColor(R.color.white));
    }

    private void setupCategorySelection() {
        View.OnClickListener categoryListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetAllCategoryBackgrounds();

                TextView selectedCategoryView = (TextView) v;
                int darkColor = getDarkColorForCategory(selectedCategoryView.getText().toString());
                selectedCategoryView.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(AddHabitActivity.this, darkColor)));
                selectedCategoryView.setTextColor(ContextCompat.getColor(AddHabitActivity.this, R.color.white));

                selectedCategory = selectedCategoryView.getText().toString();
                showToast("Selected: " + selectedCategory);
            }
        };

        catWaste.setOnClickListener(categoryListener);
        catWater.setOnClickListener(categoryListener);
        catEnergy.setOnClickListener(categoryListener);
        catFood.setOnClickListener(categoryListener);
        catTransport.setOnClickListener(categoryListener);
        catShopping.setOnClickListener(categoryListener);
    }

    private void resetAllCategoryBackgrounds() {
        TextView[] categoryViews = {catWaste, catWater, catEnergy, catFood, catTransport, catShopping};
        int[] colors = {R.color.cat_waste, R.color.cat_water, R.color.cat_energy,
                R.color.cat_food, R.color.cat_transport, R.color.cat_shopping};

        for (int i = 0; i < categoryViews.length; i++) {
            categoryViews[i].setBackgroundResource(R.drawable.bg_category);
            categoryViews[i].setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    ContextCompat.getColor(this, colors[i])));
            categoryViews[i].setTextColor(ContextCompat.getColor(this, R.color.white));
        }
    }

    private int getDarkColorForCategory(String category) {
        switch (category) {
            case "Waste Reduction":
                return R.color.cat_waste_dark;
            case "Water Conservation":
                return R.color.cat_water_dark;
            case "Energy Saving":
                return R.color.cat_energy_dark;
            case "Food Sustainability":
                return R.color.cat_food_dark;
            case "Transportation":
                return R.color.cat_transport_dark;
            case "Shopping":
                return R.color.cat_shopping_dark;
            default:
                return R.color.cat_waste_dark;
        }
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(AddHabitActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        finish();
    }

    private void increaseTarget() {
        target++;
        updateTargetDisplay();
        updateReminderUI();
    }

    private void decreaseTarget() {
        if (target > 0) {
            target--;
            updateTargetDisplay();
            updateReminderUI();
        }
    }

    private void updateTargetDisplay() {
        txtTarget.setText(String.valueOf(target));
    }

    private void saveHabit() {
        String habitName = edtHabitName.getText().toString().trim();

        // AMBIL WAKTU DARI INPUT YANG SESUAI DENGAN FREQUENCY
        String hour = "";
        String minute = "";

        if (isReminderEnabled) {
            switch (selectedFrequency) {
                case "weekly":
                    hour = edtHourWeekly.getText().toString().trim();
                    minute = edtMinuteWeekly.getText().toString().trim();
                    break;
                case "monthly":
                    hour = edtHourMonthly.getText().toString().trim();
                    minute = edtMinuteMonthly.getText().toString().trim();
                    break;
                case "yearly":
                    hour = edtHourYearly.getText().toString().trim();
                    minute = edtMinuteYearly.getText().toString().trim();
                    break;
                default: // daily - tidak perlu waktu global
                    break;
            }
        }

        // Validation
        if (TextUtils.isEmpty(habitName)) {
            showToast("Please enter habit name");
            return;
        }

        if (target == 0) {
            showToast("Please set target per period");
            return;
        }

        if (TextUtils.isEmpty(selectedCategory)) {
            showToast("Please select a category");
            return;
        }

        if (isReminderEnabled && !validateReminders()) {
            return;
        }

        try {
            Habit newHabit = createHabitObject(habitName, hour, minute);
            saveHabitToDatabase(newHabit);
            showSuccessDialog(habitName);

        } catch (Exception e) {
            showToast("Error saving habit: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean validateReminders() {
        switch (selectedFrequency) {
            case "daily":
                return validateDailyReminders();
            case "weekly":
                return validateWeeklyReminders();
            case "monthly":
                return validateMonthlyReminders();
            case "yearly":
                return validateYearlyReminders();
            default:
                return true;
        }
    }

    private boolean validateDailyReminders() {
        for (int i = 0; i < dailyTimes.size(); i++) {
            String time = dailyTimes.get(i);
            if (TextUtils.isEmpty(time)) {
                showToast("Please enter time for reminder " + (i + 1));
                return false;
            }
        }
        return true;
    }

    private boolean validateWeeklyReminders() {
        String hour = edtHourWeekly.getText().toString().trim();
        String minute = edtMinuteWeekly.getText().toString().trim();
        if (!isValidTime(hour, minute)) {
            showToast("Please enter valid time (00-23 for hour, 00-59 for minute)");
            return false;
        }
        return true;
    }

    private boolean validateMonthlyReminders() {
        String hour = edtHourMonthly.getText().toString().trim();
        String minute = edtMinuteMonthly.getText().toString().trim();
        if (!isValidTime(hour, minute)) {
            showToast("Please enter valid time (00-23 for hour, 00-59 for minute)");
            return false;
        }
        return true;
    }

    private boolean validateYearlyReminders() {
        String hour = edtHourYearly.getText().toString().trim();
        String minute = edtMinuteYearly.getText().toString().trim();
        if (!isValidTime(hour, minute)) {
            showToast("Please enter valid time (00-23 for hour, 00-59 for minute)");
            return false;
        }
        return true;
    }

    private void showSuccessDialog(String habitName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Habit Saved Successfully!");
        builder.setMessage("Your habit '" + habitName + "' has been saved successfully. You can track your progress in the habits list.");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                navigateToMainActivity();
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

    private Habit createHabitObject(String habitName, String hour, String minute) {
        String reminderTime = "";
        List<String> reminderTimes = new ArrayList<>();
        List<String> reminderDays = new ArrayList<>();
        List<String> reminderDates = new ArrayList<>();
        List<String> reminderMonths = new ArrayList<>();
        List<String> reminderYearlyDates = new ArrayList<>();

        if (isReminderEnabled) {
            switch (selectedFrequency) {
                case "daily":
                    reminderTimes = new ArrayList<>(dailyTimes);
                    break;
                case "weekly":
                    reminderTime = formatTime(hour, minute);
                    reminderDays = new ArrayList<>(weeklyDays);
                    break;
                case "monthly":
                    reminderTime = formatTime(hour, minute);
                    reminderDates = new ArrayList<>(monthlyDates);
                    break;
                case "yearly":
                    reminderTime = formatTime(hour, minute);
                    reminderMonths = new ArrayList<>(yearlyMonths);
                    reminderYearlyDates = new ArrayList<>(yearlyDates);
                    break;
            }
        }

        int colorRes = getColorForCategory(selectedCategory);

        Habit habit = new Habit(
                habitName,
                0,
                target,
                colorRes,
                selectedFrequency,
                selectedCategory,
                reminderTime,
                "",
                "",
                "",
                "",
                ""
        );

        // Set multiple reminders
        habit.setReminderTimes(reminderTimes);
        habit.setReminderDays(reminderDays);
        habit.setReminderDates(reminderDates);
        habit.setReminderMonths(reminderMonths);
        habit.setReminderYearlyDates(reminderYearlyDates);

        return habit;
    }

    private boolean isValidTime(String hour, String minute) {
        if (!isReminderEnabled) {
            return true;
        }

        if (TextUtils.isEmpty(hour) && TextUtils.isEmpty(minute)) {
            return false;
        }

        try {
            int h = Integer.parseInt(hour);
            int m = Integer.parseInt(minute);
            return (h >= 0 && h <= 23) && (m >= 0 && m <= 59);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private String formatTime(String hour, String minute) {
        if (TextUtils.isEmpty(hour) && TextUtils.isEmpty(minute)) {
            return "";
        }

        int h = TextUtils.isEmpty(hour) ? 0 : Integer.parseInt(hour);
        int m = TextUtils.isEmpty(minute) ? 0 : Integer.parseInt(minute);
        return String.format("%02d:%02d", h, m);
    }

    private void saveHabitToDatabase(Habit habit) {
        try {
            HabitDataManager dataManager = HabitDataManager.getInstance();
            dataManager.addHabit(habit);
            Toast.makeText(this, "Habit berhasil disimpan ke database!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error saveHabit: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
            throw e;
        }
    }

    private int getColorForCategory(String category) {
        switch (category) {
            case "Waste Reduction":
                return R.color.cat_waste;
            case "Water Conservation":
                return R.color.cat_water;
            case "Energy Saving":
                return R.color.cat_energy;
            case "Food Sustainability":
                return R.color.cat_food;
            case "Transportation":
                return R.color.cat_transport;
            case "Shopping":
                return R.color.cat_shopping;
            default:
                return R.color.cat_waste;
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void setupFooter() {
        setFooterActive("habits");

        findViewById(R.id.footer_home).setOnClickListener(v -> {
            showCancelConfirmation();
        });

        findViewById(R.id.footer_habits).setOnClickListener(v -> {
            Toast.makeText(this, "Already on Add Habit", Toast.LENGTH_SHORT).show();
        });

        findViewById(R.id.footer_profile).setOnClickListener(v -> {
            Intent intent = new Intent(AddHabitActivity.this, ProfileActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    private void setFooterActive(String activeTab) {
        int inactiveColor = ContextCompat.getColor(this, R.color.footer_inactive);
        int activeColor = ContextCompat.getColor(this, R.color.footer_active);

        ImageView iconHome = findViewById(R.id.icon_home);
        iconHome.setColorFilter(activeTab.equals("home") ? activeColor : inactiveColor);

        ImageView iconHabits = findViewById(R.id.icon_habits);
        iconHabits.setColorFilter(activeTab.equals("habits") ? activeColor : inactiveColor);

        ImageView iconProfile = findViewById(R.id.icon_profile);
        iconProfile.setColorFilter(activeTab.equals("profile") ? activeColor : inactiveColor);
    }
}