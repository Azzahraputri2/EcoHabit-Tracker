package com.example.ecohabit1;

import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;

import java.util.List;
import java.util.Locale;

public class AllHabitsActivity extends AppCompatActivity implements HabitDataManager.OnHabitsChangedListener {

    private TextView textTitle, textBack, textMyHabits;
    private TextView tabDaily, tabWeekly, tabMonthly, tabYearly;
    private LinearLayout habitsContainer, tabsContainer;
    private HabitDataManager dataManager;
    private ImageView btnAddHabit;
    private String currentTab = "daily";

    // PERBAIKAN: Deklarasi habitsChangedListener
    private HabitDataManager.OnHabitsChangedListener habitsChangedListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_all_habits);

        // Inisialisasi window insets untuk edge-to-edge
        View rootView = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dataManager = HabitDataManager.getInstance();

        // PERBAIKAN: Inisialisasi listener
        habitsChangedListener = this;
        dataManager.setOnHabitsChangedListener(habitsChangedListener);

        initializeViews();
        setupClickListeners();
        setupFooter();
        showHabitsForTab("daily");
    }

    private void initializeViews() {
        try {
            textTitle = findViewById(R.id.textTitle);
            textBack = findViewById(R.id.textBack);
            textMyHabits = findViewById(R.id.textMyHabits);
            tabDaily = findViewById(R.id.tabDaily);
            tabWeekly = findViewById(R.id.tabWeekly);
            tabMonthly = findViewById(R.id.tabMonthly);
            tabYearly = findViewById(R.id.tabYearly);
            habitsContainer = findViewById(R.id.habitsContainer);
            tabsContainer = findViewById(R.id.tabsContainer);
            btnAddHabit = findViewById(R.id.btnAddHabit);

            Toast.makeText(this, "Views initialized successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error initializing views: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private void setupClickListeners() {
        // Back button listener
        if (textBack != null) {
            textBack.setOnClickListener(v -> {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            });
        }

        // Add Habit Button
        btnAddHabit.setOnClickListener(v -> navigateToAddHabit());

        // Tab listeners
        View.OnClickListener tabClickListener = v -> {
            TextView selectedTab = (TextView) v;
            if (textTitle != null) {
                textTitle.setText("All Habits");
            }
            selectTab(selectedTab);

            int viewId = v.getId();
            if (viewId == R.id.tabDaily) {
                showHabitsForTab("daily");
            } else if (viewId == R.id.tabWeekly) {
                showHabitsForTab("weekly");
            } else if (viewId == R.id.tabMonthly) {
                showHabitsForTab("monthly");
            } else if (viewId == R.id.tabYearly) {
                showHabitsForTab("yearly");
            }
        };

        tabDaily.setOnClickListener(tabClickListener);
        tabWeekly.setOnClickListener(tabClickListener);
        tabMonthly.setOnClickListener(tabClickListener);
        tabYearly.setOnClickListener(tabClickListener);
    }

    private void navigateToAddHabit() {
        try {
            Intent intent = new Intent(AllHabitsActivity.this, AddHabitActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening Add Habit: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void showHabitsForTab(String tab) {
        currentTab = tab;
        if (habitsContainer == null) return;

        habitsContainer.removeAllViews();

        List<Habit> habitsToShow = getHabitsByTab(tab);

        if (habitsToShow.isEmpty()) {
            showEmptyState(tab);
        } else {
            for (int i = 0; i < habitsToShow.size(); i++) {
                Habit habit = habitsToShow.get(i);
                // PERBAIKAN: Gunakan LayoutInflater untuk membuat card dari XML
                CardView habitCard = createHabitCardFromXml(habit, tab, i);
                habitsContainer.addView(habitCard);
            }
        }
    }

    private List<Habit> getHabitsByTab(String tab) {
        if (dataManager == null) {
            dataManager = HabitDataManager.getInstance();
        }

        switch (tab) {
            case "weekly":
                return dataManager.getWeeklyHabits();
            case "monthly":
                return dataManager.getMonthlyHabits();
            case "yearly":
                return dataManager.getYearlyHabits();
            default:
                return dataManager.getDailyHabits();
        }
    }

    private void showEmptyState(String tab) {
        if (habitsContainer == null) return;

        TextView emptyText = new TextView(this);
        emptyText.setText("No " + tab + " habits yet. Add your first habit!");
        emptyText.setTextSize(16);
        emptyText.setTextColor(ContextCompat.getColor(this, R.color.text_gray));
        emptyText.setGravity(View.TEXT_ALIGNMENT_CENTER);
        emptyText.setPadding(0, dpToPx(100), 0, 0);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        emptyText.setLayoutParams(params);

        habitsContainer.addView(emptyText);
    }

    // PERBAIKAN: Method baru untuk membuat card dari XML layout
    private CardView createHabitCardFromXml(Habit habit, String frequency, int habitIndex) {
        // Inflate layout dari XML
        LayoutInflater inflater = LayoutInflater.from(this);
        CardView habitCard = (CardView) inflater.inflate(R.layout.item_habit_card, habitsContainer, false);

        // Setup views dari XML
        setupHabitCardViews(habitCard, habit, frequency, habitIndex);

        return habitCard;
    }

    // PERBAIKAN: Method untuk setup views dari XML layout dengan FlexboxLayout
    private void setupHabitCardViews(CardView habitCard, Habit habit, String frequency, int habitIndex) {
        // Find views dari XML
        View colorIndicator = habitCard.findViewById(R.id.colorIndicator);
        TextView habitName = habitCard.findViewById(R.id.habitName);
        ProgressBar progressBar = habitCard.findViewById(R.id.progressBar);
        TextView progressText = habitCard.findViewById(R.id.progressText);
        TextView percentageText = habitCard.findViewById(R.id.percentageText);

        // PERBAIKAN: Ganti LinearLayout dengan FlexboxLayout
        com.google.android.flexbox.FlexboxLayout checksContainer = habitCard.findViewById(R.id.checksContainer);

        // Set data habit
        habitName.setText(habit.getTitle());

        // Update color indicator dengan warna kategori yang benar
        int colorRes = getColorResForCategory(habit.getCategory());
        colorIndicator.setBackgroundColor(ContextCompat.getColor(this, colorRes));

        // Update progress bar
        progressBar.setProgress(habit.getProgressPercentage());
        updateProgressBarColor(progressBar, colorRes);

        // Update text color dengan warna yang benar
        percentageText.setTextColor(ContextCompat.getColor(this, colorRes));

        // Update progress text
        progressText.setText(String.format(Locale.getDefault(), "%d/%d completes", habit.getCompleted(), habit.getTotal()));
        percentageText.setText(String.format(Locale.getDefault(), "%d%%", habit.getProgressPercentage()));

        // PERBAIKAN: Sync check circles dengan data habit yang benar - UKURAN KONSISTEN
        syncCheckCirclesWithHabit(checksContainer, habit, frequency, habitIndex);

        // Set click listener untuk habit card
        habitCard.setOnClickListener(v -> openHabitDetail(frequency, habitIndex));
    }

    // PERBAIKAN: Method untuk sync check circles dengan data habit - UKURAN KONSISTEN
    private void syncCheckCirclesWithHabit(com.google.android.flexbox.FlexboxLayout container, Habit habit, String frequency, int habitIndex) {
        container.removeAllViews();

        // Gunakan data dari HabitDataManager untuk sinkronisasi
        String habitKey = dataManager.getHabitKey(frequency, habitIndex);
        boolean[] checkStates = dataManager.getCheckCircleState(habitKey);

        // PERBAIKAN: Jika tidak ada state yang disimpan, gunakan completed count dari habit
        if (checkStates == null) {
            checkStates = new boolean[habit.getTotal()];
            // Untuk data default, gunakan completed count yang sudah ada
            for (int i = 0; i < habit.getTotal(); i++) {
                checkStates[i] = i < habit.getCompleted();
            }
            // Simpan state awal ke HabitDataManager
            dataManager.saveCheckCircleState(habitKey, checkStates);
        }

        for (int i = 0; i < habit.getTotal(); i++) {
            // PERBAIKAN: Gunakan method yang KONSISTEN
            ImageView checkCircle = createConsistentCheckCircle(habit, i, frequency, habitIndex, container);

            // PERBAIKAN: Gunakan ukuran yang sesuai dengan layout (32dp)
            com.google.android.flexbox.FlexboxLayout.LayoutParams params = new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                    dpToPx(32),
                    dpToPx(32)
            );
            params.setMargins(0, 0, dpToPx(8), dpToPx(8));
            checkCircle.setLayoutParams(params);

            container.addView(checkCircle);

            // PERBAIKAN: Gunakan state dari HabitDataManager
            boolean isCompleted = i < checkStates.length ? checkStates[i] : (i < habit.getCompleted());
            updateCheckVisual(checkCircle, isCompleted);
            checkCircle.setTag(isCompleted);
        }

        // PERBAIKAN: Validasi konsistensi antara completed count dan check states
        validateAndSyncCheckStates(container, habit, frequency, habitIndex);
    }

    // PERBAIKAN BARU: Method untuk validasi dan sinkronisasi state check circles
    private void validateAndSyncCheckStates(com.google.android.flexbox.FlexboxLayout container, Habit habit, String frequency, int habitIndex) {
        String habitKey = dataManager.getHabitKey(frequency, habitIndex);
        boolean[] checkStates = dataManager.getCheckCircleState(habitKey);

        if (checkStates != null) {
            int actualCompleted = 0;
            for (boolean state : checkStates) {
                if (state) actualCompleted++;
            }

            // Jika ada perbedaan antara completed count dan actual check states, sync
            if (actualCompleted != habit.getCompleted()) {
                habit.setCompleted(actualCompleted);
                dataManager.updateHabitProgress(frequency, habitIndex, actualCompleted);

                // Update UI progress langsung
                updateHabitCardProgress(container, habit, actualCompleted);
            }
        }
    }

    // PERBAIKAN: Method createCheckCircle yang KONSISTEN
    private ImageView createConsistentCheckCircle(Habit habit, int checkIndex, String frequency, int habitIndex, com.google.android.flexbox.FlexboxLayout container) {
        ImageView checkCircle = new ImageView(this);

        checkCircle.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        checkCircle.setClickable(true);
        checkCircle.setFocusable(true);

        // PERBAIKAN: Setup click listener dengan update yang benar
        checkCircle.setOnClickListener(v -> {
            boolean currentlyFilled = checkCircle.getTag() != null && (boolean) checkCircle.getTag();
            boolean newState = !currentlyFilled;

            updateCheckVisual(checkCircle, newState);
            checkCircle.setTag(newState);

            // PERBAIKAN: Update progress dengan menghitung semua check circles
            updateHabitProgressFromChecks(habit, frequency, habitIndex, container);
        });

        return checkCircle;
    }

    // PERBAIKAN: Method untuk update progress berdasarkan semua check circles
    private void updateHabitProgressFromChecks(Habit habit, String frequency, int habitIndex, com.google.android.flexbox.FlexboxLayout container) {
        // Calculate new completed count berdasarkan SEMUA check circles
        int newCompleted = 0;

        // PERBAIKAN: Simpan state check circles ke HabitDataManager
        String habitKey = dataManager.getHabitKey(frequency, habitIndex);
        boolean[] currentStates = new boolean[container.getChildCount()];

        for (int i = 0; i < container.getChildCount(); i++) {
            ImageView check = (ImageView) container.getChildAt(i);
            boolean isChecked = check.getTag() != null && (boolean) check.getTag();
            currentStates[i] = isChecked;
            if (isChecked) {
                newCompleted++;
            }
        }

        // PERBAIKAN: Simpan state ke HabitDataManager untuk sinkronisasi
        dataManager.saveCheckCircleState(habitKey, currentStates);

        // PERBAIKAN: Pastikan completed tidak melebihi total
        if (newCompleted > habit.getTotal()) {
            newCompleted = habit.getTotal();
        }

        // Update habit dengan completed count yang baru
        habit.setCompleted(newCompleted);
        if (dataManager != null) {
            dataManager.updateHabitProgress(frequency, habitIndex, newCompleted);
        }

        // PERBAIKAN: Update UI progress langsung
        updateHabitCardProgress(container, habit, newCompleted);

        // PERBAIKAN: Panggil listener untuk refresh data
        if (habitsChangedListener != null) {
            habitsChangedListener.onHabitsChanged();
        }
    }

    // PERBAIKAN: Method baru untuk update progress card secara langsung
    private void updateHabitCardProgress(com.google.android.flexbox.FlexboxLayout container, Habit habit, int newCompleted) {
        // Find parent card view
        CardView habitCard = (CardView) container.getParent().getParent().getParent();

        // Update progress bar
        ProgressBar progressBar = habitCard.findViewById(R.id.progressBar);
        TextView progressText = habitCard.findViewById(R.id.progressText);
        TextView percentageText = habitCard.findViewById(R.id.percentageText);

        int progressPercentage = habit.getTotal() > 0 ? (newCompleted * 100) / habit.getTotal() : 0;

        progressBar.setProgress(progressPercentage);
        progressText.setText(String.format(Locale.getDefault(), "%d/%d completes", newCompleted, habit.getTotal()));
        percentageText.setText(String.format(Locale.getDefault(), "%d%%", progressPercentage));
    }

    // PERBAIKAN: Method update check visual dengan warna konsisten #F8CC9F
    private void updateCheckVisual(ImageView check, boolean isCompleted) {
        if (isCompleted) {
            check.setImageResource(R.drawable.ic_check_circle_filled);
            // Gunakan warna check circle yang konsisten #F8CC9F
            check.setColorFilter(ContextCompat.getColor(this, R.color.check_circle_color));
        } else {
            check.setImageResource(R.drawable.ic_check_circle_outline);
            // Gunakan warna check circle yang konsisten #F8CC9F untuk outline juga
            check.setColorFilter(ContextCompat.getColor(this, R.color.check_circle_color));
        }
    }

    private void openHabitDetail(String frequency, int habitIndex) {
        try {
            Intent intent = new Intent(AllHabitsActivity.this, HabitDetailActivity.class);
            intent.putExtra("HABIT_FREQUENCY", frequency);
            intent.putExtra("HABIT_INDEX", habitIndex);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } catch (Exception e) {
            Toast.makeText(this, "Error opening habit detail: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    // PERBAIKAN: Method helper untuk mendapatkan color resource berdasarkan kategori
    private int getColorResForCategory(String category) {
        switch (category) {
            case "Waste Reduction":
                return R.color.cat_waste;
            case "Water Conservation":
                return R.color.cat_water;
            case "Energy Saving":
                return R.color.cat_energy;
            case "Food Sustainability":
                return R.color.cat_food;
            case "Transportation":
                return R.color.cat_transport;
            case "Shopping":
                return R.color.cat_shopping;
            default:
                return R.color.cat_waste;
        }
    }

    // PERBAIKAN: Method update progress bar color yang lebih baik
    private void updateProgressBarColor(ProgressBar progressBar, int colorRes) {
        try {
            // Coba update progress drawable secara langsung
            progressBar.getProgressDrawable().setColorFilter(
                    ContextCompat.getColor(this, colorRes),
                    android.graphics.PorterDuff.Mode.SRC_IN
            );
        } catch (Exception e) {
            // Fallback ke custom progress drawable berdasarkan warna
            try {
                int progressDrawableRes = getProgressDrawableForColor(colorRes);
                progressBar.setProgressDrawable(ContextCompat.getDrawable(this, progressDrawableRes));
            } catch (Exception ex) {
                // Final fallback - set color filter langsung
                progressBar.getProgressDrawable().setColorFilter(
                        ContextCompat.getColor(this, colorRes),
                        android.graphics.PorterDuff.Mode.SRC_IN
                );
            }
        }
    }

    // PERBAIKAN: Method untuk mendapatkan progress drawable berdasarkan warna kategori
    private int getProgressDrawableForColor(int colorRes) {
        if (colorRes == R.color.cat_waste) {
            return R.drawable.progress_bar_waste;
        } else if (colorRes == R.color.cat_water) {
            return R.drawable.progress_bar_water;
        } else if (colorRes == R.color.cat_energy) {
            return R.drawable.progress_bar_energy;
        } else if (colorRes == R.color.cat_food) {
            return R.drawable.progress_bar_food;
        } else if (colorRes == R.color.cat_transport) {
            return R.drawable.progress_bar_transport;
        } else if (colorRes == R.color.cat_shopping) {
            return R.drawable.progress_bar_shopping;
        } else {
            return R.drawable.progress_bar_waste;
        }
    }

    private void selectTab(TextView selectedTab) {
        // Reset all tabs
        TextView[] tabs = {tabDaily, tabWeekly, tabMonthly, tabYearly};
        int unselectedTextColor = ContextCompat.getColor(this, R.color.tab_unselected_text);
        int selectedTextColor = ContextCompat.getColor(this, R.color.tab_selected_text);

        for (TextView tab : tabs) {
            if (tab != null) {
                tab.setBackgroundResource(R.drawable.tab_background);
                tab.setTextColor(unselectedTextColor);
            }
        }

        // Set selected tab
        if (selectedTab != null) {
            selectedTab.setBackgroundResource(R.drawable.tab_background_selected);
            selectedTab.setTextColor(selectedTextColor);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    // PERBAIKAN: Perbaikan navigation footer
    private void setupFooter() {
        // Habits is active in this activity
        setFooterActive("habits");

        // Set click listeners
        View footerHome = findViewById(R.id.footer_home);
        View footerHabits = findViewById(R.id.footer_habits);
        View footerProfile = findViewById(R.id.footer_profile);

        if (footerHome != null) {
            footerHome.setOnClickListener(v -> {
                // Arahkan ke MainActivity dengan clear top (dari kode 1)
                Intent intent = new Intent(AllHabitsActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            });
        }

        if (footerHabits != null) {
            footerHabits.setOnClickListener(v -> {
                // Already on habits, do nothing
                Toast.makeText(this, "Already on Habits", Toast.LENGTH_SHORT).show();
            });
        }

        if (footerProfile != null) {
            footerProfile.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(AllHabitsActivity.this, ProfileActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } catch (Exception e) {
                    Toast.makeText(this, "ProfileActivity not found", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
            });
        }
    }

    private void setFooterActive(String activeTab) {
        int inactiveColor = ContextCompat.getColor(this, R.color.footer_inactive);
        int activeColor = ContextCompat.getColor(this, R.color.footer_active);

        ImageView iconHome = findViewById(R.id.icon_home);
        ImageView iconHabits = findViewById(R.id.icon_habits);
        ImageView iconProfile = findViewById(R.id.icon_profile);

        if (iconHome != null) {
            iconHome.setColorFilter(activeTab.equals("home") ? activeColor : inactiveColor);
        }
        if (iconHabits != null) {
            iconHabits.setColorFilter(activeTab.equals("habits") ? activeColor : inactiveColor);
        }
        if (iconProfile != null) {
            iconProfile.setColorFilter(activeTab.equals("profile") ? activeColor : inactiveColor);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshHabitData();
    }

    private void refreshHabitData() {
        showHabitsForTab(currentTab);
    }

    @Override
    public void onHabitsChanged() {
        runOnUiThread(this::refreshHabitData);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // PERBAIKAN: Hapus listener untuk menghindari memory leak
        if (dataManager != null) {
            dataManager.setOnHabitsChangedListener(null);
        }
    }
}