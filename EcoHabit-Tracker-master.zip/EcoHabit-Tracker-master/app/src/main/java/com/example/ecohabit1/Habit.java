package com.example.ecohabit1;

import java.util.ArrayList;
import java.util.List;

public class Habit {
    private String title;
    private int completed;
    private int total;
    private int colorRes;
    private String frequency;
    private String category;
    private String reminderTime;
    private String notes;
    private String reminderDay;
    private String reminderMonthlyDate;
    private String reminderYearlyMonth;
    private String reminderYearlyDate;

    // Fields untuk multiple reminders
    private List<String> reminderTimes = new ArrayList<>();
    private List<String> reminderDays = new ArrayList<>();
    private List<String> reminderDates = new ArrayList<>();
    private List<String> reminderMonths = new ArrayList<>();
    private List<String> reminderYearlyDates = new ArrayList<>();

    public Habit(String title, int completed, int total, int colorRes, String frequency,
                 String category, String reminderTime, String notes, String reminderDay,
                 String reminderMonthlyDate, String reminderYearlyMonth, String reminderYearlyDate) {
        this.title = title;
        // PERBAIKAN: Batasi completed agar tidak melebihi total
        this.completed = Math.min(completed, total);
        this.total = total;
        this.colorRes = colorRes;
        this.frequency = frequency;
        this.category = category;
        this.reminderTime = reminderTime;
        this.notes = notes;
        this.reminderDay = reminderDay;
        this.reminderMonthlyDate = reminderMonthlyDate;
        this.reminderYearlyMonth = reminderYearlyMonth;
        this.reminderYearlyDate = reminderYearlyDate;
    }

    // Getters and setters untuk fields lama
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getCompleted() { return completed; }
    public void setCompleted(int completed) {
        // PERBAIKAN: Batasi completed agar tidak melebihi total
        this.completed = Math.min(completed, total);
    }

    public int getTotal() { return total; }
    public void setTotal(int total) {
        this.total = total;
        // PERBAIKAN: Pastikan completed tidak melebihi total baru
        this.completed = Math.min(this.completed, total);
    }

    public int getColorRes() { return colorRes; }
    public void setColorRes(int colorRes) { this.colorRes = colorRes; }

    public String getFrequency() { return frequency; }
    public void setFrequency(String frequency) { this.frequency = frequency; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getReminderTime() { return reminderTime; }
    public void setReminderTime(String reminderTime) { this.reminderTime = reminderTime; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getReminderDay() { return reminderDay; }
    public void setReminderDay(String reminderDay) { this.reminderDay = reminderDay; }

    public String getReminderMonthlyDate() { return reminderMonthlyDate; }
    public void setReminderMonthlyDate(String reminderMonthlyDate) { this.reminderMonthlyDate = reminderMonthlyDate; }

    public String getReminderYearlyMonth() { return reminderYearlyMonth; }
    public void setReminderYearlyMonth(String reminderYearlyMonth) { this.reminderYearlyMonth = reminderYearlyMonth; }

    public String getReminderYearlyDate() { return reminderYearlyDate; }
    public void setReminderYearlyDate(String reminderYearlyDate) { this.reminderYearlyDate = reminderYearlyDate; }

    // GETTERS AND SETTERS untuk multiple reminders
    public List<String> getReminderTimes() { return reminderTimes; }
    public void setReminderTimes(List<String> reminderTimes) {
        this.reminderTimes = reminderTimes != null ? reminderTimes : new ArrayList<>();
    }

    public List<String> getReminderDays() { return reminderDays; }
    public void setReminderDays(List<String> reminderDays) {
        this.reminderDays = reminderDays != null ? reminderDays : new ArrayList<>();
    }

    public List<String> getReminderDates() { return reminderDates; }
    public void setReminderDates(List<String> reminderDates) {
        this.reminderDates = reminderDates != null ? reminderDates : new ArrayList<>();
    }

    public List<String> getReminderMonths() { return reminderMonths; }
    public void setReminderMonths(List<String> reminderMonths) {
        this.reminderMonths = reminderMonths != null ? reminderMonths : new ArrayList<>();
    }

    public List<String> getReminderYearlyDates() { return reminderYearlyDates; }
    public void setReminderYearlyDates(List<String> reminderYearlyDates) {
        this.reminderYearlyDates = reminderYearlyDates != null ? reminderYearlyDates : new ArrayList<>();
    }

    // Helper methods
    public int getProgressPercentage() {
        if (total == 0) return 0;
        // PERBAIKAN: Pastikan completed tidak melebihi total sebelum menghitung
        int actualCompleted = Math.min(completed, total);
        int percentage = (actualCompleted * 100) / total;
        // PERBAIKAN: Batasi maksimal 100%
        return Math.min(percentage, 100);
    }

    public boolean isCompleted() {
        return completed >= total;
    }

    public void incrementCompleted() {
        if (completed < total) {
            completed++;
        }
        // PERBAIKAN: Completed tidak akan melebihi total
    }

    public void decrementCompleted() {
        if (completed > 0) {
            completed--;
        }
    }

    // PERBAIKAN: Method untuk validasi data habit
    public boolean isValid() {
        return title != null && !title.trim().isEmpty() &&
                total > 0 &&
                completed >= 0 && completed <= total;
    }
}