package com.example.ecohabit1;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import android.util.Log;

public class HabitDataManager {
    private static HabitDataManager instance;
    private final List<Habit> dailyHabits = new ArrayList<>();
    private final List<Habit> weeklyHabits = new ArrayList<>();
    private final List<Habit> monthlyHabits = new ArrayList<>();
    private final List<Habit> yearlyHabits = new ArrayList<>();

    // Untuk check circle states
    private Map<String, boolean[]> checkCircleStates = new HashMap<>();
    private OnHabitsChangedListener habitsChangedListener;

    public interface OnHabitsChangedListener {
        void onHabitsChanged();
    }

    // PRIVATE CONSTRUCTOR
    private HabitDataManager() {
        initializeDefaultData();
    }

    public static HabitDataManager getInstance() {
        if (instance == null) {
            instance = new HabitDataManager();
            Log.d("HabitDataManager", "✅ New instance created");
        }
        return instance;
    }

    // METHOD BARU: Initialize data hanya sekali
    public void initializeDefaultData() {
        // Cek apakah data sudah ada untuk menghindari duplikasi
        if (!dailyHabits.isEmpty() || !weeklyHabits.isEmpty() ||
                !monthlyHabits.isEmpty() || !yearlyHabits.isEmpty()) {
            Log.d("HabitDataManager", "ℹ️ Data already initialized, skipping...");
            return;
        }

        Log.d("HabitDataManager", "🔄 Initializing default data...");

        try {
            // DAILY HABITS
            dailyHabits.add(new Habit("Bring Reusable Bottle", 1, 1, R.color.cat_waste,
                    "daily", "Waste Reduction", "08:00", "Bring your own tumbler to reduce plastic waste",
                    "", "", "", ""));
            dailyHabits.add(new Habit("Turn Off Unused Lights", 3, 5, R.color.cat_energy,
                    "daily", "Energy Saving", "22:00", "Save electricity by turning off lights when not in use",
                    "", "", "", ""));
            dailyHabits.add(new Habit("No Single-Use Plastics", 1, 1, R.color.cat_waste,
                    "daily", "Waste Reduction", "", "Avoid using single-use plastic items",
                    "", "", "", ""));

            // WEEKLY HABITS
            weeklyHabits.add(new Habit("Trash Sorting & Recycling", 2, 3, R.color.cat_waste,
                    "weekly", "Waste Reduction", "19:00", "Sort and recycle waste properly",
                    "Monday", "", "", ""));
            weeklyHabits.add(new Habit("Use Public Transport / Bike", 4, 4, R.color.cat_transport,
                    "weekly", "Transportation", "08:00", "Reduce carbon footprint by using eco-friendly transport",
                    "Friday", "", "", ""));
            weeklyHabits.add(new Habit("Plastic-Free Grocery Shopping", 1, 1, R.color.cat_shopping,
                    "weekly", "Shopping", "10:00", "Bring reusable bags for shopping",
                    "Saturday", "", "", ""));

            // MONTHLY HABITS
            monthlyHabits.add(new Habit("Declutter & Donate Items", 1, 2, R.color.cat_shopping,
                    "monthly", "Shopping", "15:00", "Declutter and donate unused items",
                    "", "15", "", ""));
            monthlyHabits.add(new Habit("Participate in Clean-Up Activity", 1, 1, R.color.cat_waste,
                    "monthly", "Waste Reduction", "09:00", "Join community clean-up activities",
                    "", "1", "", ""));
            monthlyHabits.add(new Habit("Bulk Buying Restock", 1, 1, R.color.cat_shopping,
                    "monthly", "Shopping", "14:00", "Buy in bulk to reduce packaging waste",
                    "", "28", "", ""));

            // YEARLY HABITS
            yearlyHabits.add(new Habit("Conduct a full home energy audit", 2, 3, R.color.cat_energy,
                    "yearly", "Energy Saving", "", "Check home energy efficiency annually",
                    "", "", "January", "15"));
            yearlyHabits.add(new Habit("Upgrade to energy-saving appliances", 4, 4, R.color.cat_energy,
                    "yearly", "Energy Saving", "", "Replace old appliances with energy-efficient ones",
                    "", "", "June", "1"));
            yearlyHabits.add(new Habit("Travel domestically using low-impact options", 1, 1, R.color.cat_transport,
                    "yearly", "Transportation", "", "Choose eco-friendly travel options",
                    "", "", "December", "25"));

            // Initialize check circle states
            initializeDefaultCheckCircleStates();

            Log.d("HabitDataManager", "✅ Default data initialized successfully");
            debugPrintAllHabits();

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error initializing default data: " + e.getMessage(), e);
        }
    }

    // PERBAIKAN: Inisialisasi state check circles untuk data default
    private void initializeDefaultCheckCircleStates() {
        try {
            checkCircleStates.clear(); // Clear dulu semua states

            // Daily habits - beri state sesuai completed count
            for (int i = 0; i < dailyHabits.size(); i++) {
                Habit habit = dailyHabits.get(i);
                String habitKey = getHabitKey("daily", i);
                initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
            }

            // Weekly habits - beri state sesuai completed count
            for (int i = 0; i < weeklyHabits.size(); i++) {
                Habit habit = weeklyHabits.get(i);
                String habitKey = getHabitKey("weekly", i);
                initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
            }

            // Monthly habits - beri state sesuai completed count
            for (int i = 0; i < monthlyHabits.size(); i++) {
                Habit habit = monthlyHabits.get(i);
                String habitKey = getHabitKey("monthly", i);
                initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
            }

            // Yearly habits - beri state sesuai completed count
            for (int i = 0; i < yearlyHabits.size(); i++) {
                Habit habit = yearlyHabits.get(i);
                String habitKey = getHabitKey("yearly", i);
                initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
            }

            Log.d("HabitDataManager", "✅ Check circle states initialized: " + checkCircleStates.size() + " entries");
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error initializing check circle states: " + e.getMessage(), e);
        }
    }

    // ==================== CORE METHODS ====================

    // DELETE HABIT - Sederhana dan Aman
    public void deleteHabit(String frequency, int habitIndex) {
        try {
            Log.d("HabitDataManager", "🗑️ Deleting habit: " + frequency + " index " + habitIndex);

            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            if (habitIndex >= 0 && habitIndex < habits.size()) {
                Habit deletedHabit = habits.remove(habitIndex);

                // Remove check circle state
                String habitKey = getHabitKey(frequency, habitIndex);
                checkCircleStates.remove(habitKey);

                // PERBAIKAN: Update check states setelah delete
                updateCheckCircleStatesAfterDelete(frequency, habitIndex);

                Log.d("HabitDataManager", "✅ Deleted: " + deletedHabit.getTitle());
                notifyHabitsChanged();
            } else {
                Log.e("HabitDataManager", "❌ Invalid index for deletion: " + habitIndex);
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error deleting habit: " + e.getMessage(), e);
        }
    }

    // PERBAIKAN: Method untuk delete yang lebih aman
    public boolean safeDeleteHabit(String frequency, int habitIndex) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            if (habitIndex >= 0 && habitIndex < habits.size()) {
                Habit deletedHabit = habits.remove(habitIndex);

                // Hapus check circle state
                String habitKey = getHabitKey(frequency, habitIndex);
                checkCircleStates.remove(habitKey);

                // PERBAIKAN: Update keys untuk habit setelah yang dihapus
                updateCheckCircleStatesAfterDelete(frequency, habitIndex);

                Log.d("HabitDataManager", "✅ Deleted: " + deletedHabit.getTitle() + " from " + frequency);
                notifyHabitsChanged();
                return true;
            } else {
                Log.e("HabitDataManager", "❌ Invalid index for deletion: " + habitIndex);
                return false;
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error in safeDeleteHabit: " + e.getMessage(), e);
            return false;
        }
    }

    // PERBAIKAN: Update keys setelah delete
    private void updateCheckCircleStatesAfterDelete(String frequency, int deletedIndex) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);
            Map<String, boolean[]> updatedStates = new HashMap<>();

            // Simpan semua states yang tidak berubah
            for (String key : checkCircleStates.keySet()) {
                if (!key.startsWith(frequency + "_")) {
                    updatedStates.put(key, checkCircleStates.get(key));
                }
            }

            // Rebuild states untuk frequency ini
            for (int i = 0; i < habits.size(); i++) {
                String newKey = getHabitKey(frequency, i);
                String oldKey = getHabitKey(frequency, i < deletedIndex ? i : i + 1);

                boolean[] oldState = checkCircleStates.get(oldKey);
                if (oldState != null) {
                    updatedStates.put(newKey, oldState);
                } else {
                    // Buat state baru jika tidak ada
                    Habit habit = habits.get(i);
                    initializeCheckCircleStateFromCompleted(newKey, habit.getTotal(), habit.getCompleted());
                    updatedStates.put(newKey, checkCircleStates.get(newKey));
                }
            }

            // Update checkCircleStates dengan yang baru
            checkCircleStates.clear();
            checkCircleStates.putAll(updatedStates);

            Log.d("HabitDataManager", "🔄 Updated check states after delete at index " + deletedIndex);

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error updating check states after delete: " + e.getMessage(), e);
        }
    }

    // PERBAIKAN BESAR: ADD HABIT - Fix untuk check circles yang tercentang otomatis
    public void addHabit(Habit habit) {
        try {
            if (habit == null) {
                Log.e("HabitDataManager", "❌ Cannot add null habit");
                return;
            }

            if (!habit.isValid()) {
                Log.e("HabitDataManager", "❌ Invalid habit for addition: " + habit.getTitle());
                return;
            }

            String frequency = habit.getFrequency();
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            // PERBAIKAN: Simpan semua states untuk frequency ini sebelum menambah
            Map<Integer, boolean[]> oldStatesForFrequency = new HashMap<>();
            for (int i = 0; i < habits.size(); i++) {
                String oldKey = getHabitKey(frequency, i);
                boolean[] oldState = checkCircleStates.get(oldKey);
                if (oldState != null) {
                    oldStatesForFrequency.put(i, oldState);
                }
            }

            // Add to beginning
            habits.add(0, habit);

            // PERBAIKAN: Hapus semua states untuk frequency ini
            List<String> keysToRemove = new ArrayList<>();
            for (String key : checkCircleStates.keySet()) {
                if (key.startsWith(frequency + "_")) {
                    keysToRemove.add(key);
                }
            }
            for (String key : keysToRemove) {
                checkCircleStates.remove(key);
            }

            // PERBAIKAN: Rebuild states dengan urutan yang benar
            for (int i = 0; i < habits.size(); i++) {
                Habit currentHabit = habits.get(i);
                String newKey = getHabitKey(frequency, i);

                if (i == 0) {
                    // Habit baru di index 0 - buat state KOSONG
                    initializeEmptyCheckCircleState(newKey, currentHabit.getTotal());
                    Log.d("HabitDataManager", "🔄 Created EMPTY state for NEW habit: " + currentHabit.getTitle());
                } else {
                    // Habit lama - gunakan state dari index sebelumnya
                    int oldIndex = i - 1;
                    boolean[] oldState = oldStatesForFrequency.get(oldIndex);
                    if (oldState != null && oldState.length == currentHabit.getTotal()) {
                        checkCircleStates.put(newKey, oldState);
                        Log.d("HabitDataManager", "🔄 Moved state from index " + oldIndex + " to " + i);
                    } else {
                        // Buat state baru berdasarkan completed count
                        initializeCheckCircleStateFromCompleted(newKey, currentHabit.getTotal(), currentHabit.getCompleted());
                        Log.d("HabitDataManager", "🔄 Created new state for: " + currentHabit.getTitle());
                    }
                }
            }

            Log.d("HabitDataManager", "✅ Added: " + habit.getTitle() + " to " + frequency +
                    " (Total habits: " + habits.size() + ")");
            notifyHabitsChanged();

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error adding habit: " + e.getMessage(), e);
        }
    }

    // UPDATE HABIT - Hanya untuk frequency yang sama
    public void updateHabit(String frequency, int habitIndex, Habit updatedHabit) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            if (habitIndex < 0 || habitIndex >= habits.size()) {
                Log.e("HabitDataManager", "❌ Invalid index for update: " + habitIndex);
                return;
            }

            if (updatedHabit == null || !updatedHabit.isValid()) {
                Log.e("HabitDataManager", "❌ Invalid habit for update");
                return;
            }

            // PERBAIKAN: Update properties satu per satu untuk menghindari reference issues
            Habit existingHabit = habits.get(habitIndex);
            existingHabit.setTitle(updatedHabit.getTitle());
            existingHabit.setTotal(updatedHabit.getTotal());
            existingHabit.setCompleted(updatedHabit.getCompleted());
            existingHabit.setColorRes(updatedHabit.getColorRes());
            existingHabit.setFrequency(updatedHabit.getFrequency());
            existingHabit.setCategory(updatedHabit.getCategory());
            existingHabit.setReminderTime(updatedHabit.getReminderTime());
            existingHabit.setNotes(updatedHabit.getNotes());
            existingHabit.setReminderDay(updatedHabit.getReminderDay());
            existingHabit.setReminderMonthlyDate(updatedHabit.getReminderMonthlyDate());
            existingHabit.setReminderYearlyMonth(updatedHabit.getReminderYearlyMonth());
            existingHabit.setReminderYearlyDate(updatedHabit.getReminderYearlyDate());

            // Update multiple reminders
            existingHabit.setReminderTimes(updatedHabit.getReminderTimes());
            existingHabit.setReminderDays(updatedHabit.getReminderDays());
            existingHabit.setReminderDates(updatedHabit.getReminderDates());
            existingHabit.setReminderMonths(updatedHabit.getReminderMonths());
            existingHabit.setReminderYearlyDates(updatedHabit.getReminderYearlyDates());

            Log.d("HabitDataManager", "✅ Updated: " + updatedHabit.getTitle());
            notifyHabitsChanged();

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error updating habit: " + e.getMessage(), e);
        }
    }

    // PERBAIKAN: Method untuk update habit yang lebih aman
    public boolean safeUpdateHabit(String oldFrequency, int oldIndex, Habit updatedHabit) {
        try {
            String newFrequency = updatedHabit.getFrequency();
            Log.d("HabitDataManager", "🔄 Safe update - Old: " + oldFrequency + "[" + oldIndex + "], New: " + newFrequency);

            // Jika frequency berubah, pindahkan habit
            if (!oldFrequency.equals(newFrequency)) {
                return moveHabitSafely(oldFrequency, oldIndex, updatedHabit);
            } else {
                // Jika frequency sama, update di tempat
                return updateHabitInPlace(oldFrequency, oldIndex, updatedHabit);
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error in safeUpdateHabit: " + e.getMessage(), e);
            return false;
        }
    }

    // PERBAIKAN: Method untuk memindahkan habit dengan aman
    private boolean moveHabitSafely(String oldFrequency, int oldIndex, Habit newHabit) {
        try {
            List<Habit> oldHabits = getHabitsByFrequencyInternal(oldFrequency);
            List<Habit> newHabits = getHabitsByFrequencyInternal(newHabit.getFrequency());

            // Validasi index lama
            if (oldIndex < 0 || oldIndex >= oldHabits.size()) {
                Log.e("HabitDataManager", "❌ Invalid old index for move: " + oldIndex);
                return false;
            }

            // Simpan habit yang akan dipindahkan
            Habit habitToMove = oldHabits.get(oldIndex);

            // Hapus dari list lama
            oldHabits.remove(oldIndex);

            // Hapus check circle state lama
            String oldHabitKey = getHabitKey(oldFrequency, oldIndex);
            checkCircleStates.remove(oldHabitKey);

            // Update keys untuk habit setelah yang dipindahkan
            updateCheckCircleStatesAfterDelete(oldFrequency, oldIndex);

            // Tambahkan ke list baru (di awal)
            newHabits.add(0, newHabit);

            // PERBAIKAN: Rebuild check states untuk frequency baru
            rebuildCheckCircleStatesForFrequency(newHabit.getFrequency());

            Log.d("HabitDataManager", "✅ Moved habit: " + habitToMove.getTitle() +
                    " from " + oldFrequency + " to " + newHabit.getFrequency());

            notifyHabitsChanged();
            return true;

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error moving habit: " + e.getMessage(), e);
            return false;
        }
    }

    // PERBAIKAN: Method untuk update di tempat
    private boolean updateHabitInPlace(String frequency, int index, Habit updatedHabit) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            if (index < 0 || index >= habits.size()) {
                Log.e("HabitDataManager", "❌ Invalid index for update: " + index);
                return false;
            }

            // Update properties satu per satu
            Habit existingHabit = habits.get(index);
            existingHabit.setTitle(updatedHabit.getTitle());
            existingHabit.setTotal(updatedHabit.getTotal());
            existingHabit.setCompleted(updatedHabit.getCompleted());
            existingHabit.setColorRes(updatedHabit.getColorRes());
            existingHabit.setCategory(updatedHabit.getCategory());
            existingHabit.setReminderTime(updatedHabit.getReminderTime());
            existingHabit.setNotes(updatedHabit.getNotes());

            // Update multiple reminders
            existingHabit.setReminderTimes(updatedHabit.getReminderTimes());
            existingHabit.setReminderDays(updatedHabit.getReminderDays());
            existingHabit.setReminderDates(updatedHabit.getReminderDates());
            existingHabit.setReminderMonths(updatedHabit.getReminderMonths());
            existingHabit.setReminderYearlyDates(updatedHabit.getReminderYearlyDates());

            Log.d("HabitDataManager", "✅ Updated in place: " + updatedHabit.getTitle());
            notifyHabitsChanged();
            return true;

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error updating habit in place: " + e.getMessage(), e);
            return false;
        }
    }

    // PERBAIKAN: Method untuk rebuild check circle states
    private void rebuildCheckCircleStatesForFrequency(String frequency) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            // Hapus semua check states untuk frequency ini
            List<String> keysToRemove = new ArrayList<>();
            for (String key : checkCircleStates.keySet()) {
                if (key.startsWith(frequency + "_")) {
                    keysToRemove.add(key);
                }
            }
            for (String key : keysToRemove) {
                checkCircleStates.remove(key);
            }

            // Buat ulang check states untuk semua habits di frequency ini
            for (int i = 0; i < habits.size(); i++) {
                Habit habit = habits.get(i);
                String habitKey = getHabitKey(frequency, i);

                // Buat state baru berdasarkan completed count
                initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
            }

            Log.d("HabitDataManager", "✅ Rebuilt check states for " + frequency +
                    " (" + habits.size() + " habits)");
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error rebuilding check states for " + frequency, e);
        }
    }

    // MOVE HABIT - Untuk ganti frequency (DELETE + ADD)
    public void moveHabit(String oldFrequency, int oldIndex, Habit newHabit) {
        try {
            Log.d("HabitDataManager", "🔄 Moving habit from " + oldFrequency + "[" + oldIndex + "] to " + newHabit.getFrequency());

            // 1. Delete dari frequency lama
            deleteHabit(oldFrequency, oldIndex);

            // 2. Add ke frequency baru
            addHabit(newHabit);

            Log.d("HabitDataManager", "✅ Move completed successfully");

        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error moving habit: " + e.getMessage(), e);
        }
    }

    // ==================== GETTER METHODS ====================

    public List<Habit> getDailyHabits() {
        return new ArrayList<>(dailyHabits);
    }

    public List<Habit> getWeeklyHabits() {
        return new ArrayList<>(weeklyHabits);
    }

    public List<Habit> getMonthlyHabits() {
        return new ArrayList<>(monthlyHabits);
    }

    public List<Habit> getYearlyHabits() {
        return new ArrayList<>(yearlyHabits);
    }

    public List<Habit> getAllHabits() {
        List<Habit> allHabits = new ArrayList<>();
        allHabits.addAll(dailyHabits);
        allHabits.addAll(weeklyHabits);
        allHabits.addAll(monthlyHabits);
        allHabits.addAll(yearlyHabits);
        return allHabits;
    }

    public List<Habit> getHabitsByFrequency(String frequency) {
        switch (frequency.toLowerCase()) {
            case "weekly": return getWeeklyHabits();
            case "monthly": return getMonthlyHabits();
            case "yearly": return getYearlyHabits();
            case "daily":
            default: return getDailyHabits();
        }
    }

    public List<Habit> getHabitsByCategory(String category) {
        List<Habit> categoryHabits = new ArrayList<>();
        for (Habit habit : getAllHabits()) {
            if (habit.getCategory().equals(category)) {
                categoryHabits.add(habit);
            }
        }
        return categoryHabits;
    }

    // PERBAIKAN: Method untuk mendapatkan habit dengan index yang aman
    public Habit getHabitByFrequencyAndIndex(String frequency, int index) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);

            if (index >= 0 && index < habits.size()) {
                return habits.get(index);
            } else {
                Log.e("HabitDataManager", "❌ Index out of bounds: " + index + " for frequency: " + frequency);
                return null;
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error getting habit: " + e.getMessage(), e);
            return null;
        }
    }

    // PERBAIKAN BARU: Method untuk mendapatkan habit dengan validasi check states
    public Habit getHabitByFrequencyAndIndexWithCheckSync(String frequency, int index) {
        try {
            Habit habit = getHabitByFrequencyAndIndex(frequency, index);
            if (habit != null) {
                ensureCheckStatesConsistencyForHabit(frequency, index, habit);
            }
            return habit;
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error getting habit with check sync", e);
            return null;
        }
    }

    // ==================== PROGRESS METHODS ====================

    public void updateHabitProgress(String frequency, int habitIndex, int completed) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);
            if (habitIndex >= 0 && habitIndex < habits.size()) {
                habits.get(habitIndex).setCompleted(completed);
                notifyHabitsChanged();
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "Error updating habit progress: " + e.getMessage(), e);
        }
    }

    public void updateHabitProgressWithCheckSync(String frequency, int habitIndex, int completed, boolean[] checkStates) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);
            if (habitIndex >= 0 && habitIndex < habits.size()) {
                Habit habit = habits.get(habitIndex);
                int actualCompleted = Math.min(completed, habit.getTotal());
                habit.setCompleted(actualCompleted);

                String habitKey = getHabitKey(frequency, habitIndex);
                saveCheckCircleState(habitKey, checkStates);

                notifyHabitsChanged();
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "Error updating habit progress with check sync: " + e.getMessage(), e);
        }
    }

    public void incrementHabitProgress(String frequency, int habitIndex) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);
            if (habitIndex >= 0 && habitIndex < habits.size()) {
                habits.get(habitIndex).incrementCompleted();
                notifyHabitsChanged();
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "Error incrementing habit progress: " + e.getMessage(), e);
        }
    }

    public void decrementHabitProgress(String frequency, int habitIndex) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);
            if (habitIndex >= 0 && habitIndex < habits.size()) {
                habits.get(habitIndex).decrementCompleted();
                notifyHabitsChanged();
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "Error decrementing habit progress: " + e.getMessage(), e);
        }
    }

    // ==================== CHECK CIRCLE METHODS ====================

    public String getHabitKey(String frequency, int habitIndex) {
        return frequency + "_" + habitIndex;
    }

    public void initializeEmptyCheckCircleState(String habitKey, int totalChecks) {
        boolean[] states = new boolean[totalChecks];
        for (int i = 0; i < totalChecks; i++) {
            states[i] = false;
        }
        checkCircleStates.put(habitKey, states);
        Log.d("HabitDataManager", "🔄 Created EMPTY state for: " + habitKey);
    }

    public boolean[] getCheckCircleState(String habitKey) {
        return checkCircleStates.get(habitKey);
    }

    public void saveCheckCircleState(String habitKey, boolean[] states) {
        checkCircleStates.put(habitKey, states);
    }

    public void removeCheckCircleState(String habitKey) {
        checkCircleStates.remove(habitKey);
    }

    // PERBAIKAN BARU: Method untuk inisialisasi state check circles berdasarkan completed count
    private void initializeCheckCircleStateFromCompleted(String habitKey, int totalChecks, int completedCount) {
        boolean[] states = new boolean[totalChecks];
        int actualCompleted = Math.min(completedCount, totalChecks);
        for (int i = 0; i < totalChecks; i++) {
            states[i] = i < actualCompleted;
        }
        checkCircleStates.put(habitKey, states);
        Log.d("HabitDataManager", "🔄 Created state for: " + habitKey + " - " + actualCompleted + "/" + totalChecks);
    }

    // PERBAIKAN BARU: Method untuk memastikan check states konsisten
    public void ensureCheckStatesConsistency() {
        try {
            Log.d("HabitDataManager", "🔄 Ensuring check states consistency...");

            String[] frequencies = {"daily", "weekly", "monthly", "yearly"};

            for (String frequency : frequencies) {
                List<Habit> habits = getHabitsByFrequencyInternal(frequency);

                for (int i = 0; i < habits.size(); i++) {
                    Habit habit = habits.get(i);
                    String habitKey = getHabitKey(frequency, i);
                    boolean[] currentState = checkCircleStates.get(habitKey);

                    // Jika state tidak ada atau tidak sesuai dengan total, buat yang baru
                    if (currentState == null || currentState.length != habit.getTotal()) {
                        Log.d("HabitDataManager", "🔄 Fixing inconsistent state for: " + habit.getTitle() +
                                " (expected: " + habit.getTotal() + ", actual: " +
                                (currentState != null ? currentState.length : "null") + ")");
                        initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
                    }
                }
            }

            Log.d("HabitDataManager", "✅ Check states consistency ensured");
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error ensuring check states consistency", e);
        }
    }

    // PERBAIKAN BARU: Method untuk memastikan check state konsisten untuk habit tertentu
    public void ensureCheckStatesConsistencyForHabit(String frequency, int index, Habit habit) {
        try {
            String habitKey = getHabitKey(frequency, index);
            boolean[] currentState = checkCircleStates.get(habitKey);

            // Jika state tidak ada atau tidak sesuai, buat yang baru
            if (currentState == null || currentState.length != habit.getTotal()) {
                Log.d("HabitDataManager", "🔄 Fixing state for: " + habit.getTitle() +
                        " (expected: " + habit.getTotal() + ", actual: " +
                        (currentState != null ? currentState.length : "null") + ")");
                initializeCheckCircleStateFromCompleted(habitKey, habit.getTotal(), habit.getCompleted());
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "❌ Error ensuring check state consistency for habit", e);
        }
    }

    // PERBAIKAN BARU: Method untuk mendapatkan habit index terbaru
    public int getLatestHabitIndex(String frequency) {
        List<Habit> habits = getHabitsByFrequencyInternal(frequency);
        return habits.isEmpty() ? 0 : habits.size() - 1;
    }

    // ==================== STATISTICS METHODS ====================

    public int getTotalCompletedHabits() {
        int total = 0;
        for (Habit habit : getAllHabits()) {
            if (habit.isCompleted()) {
                total++;
            }
        }
        return total;
    }

    public int getTotalHabitsCount() {
        return getAllHabits().size();
    }

    public int getOverallCompletionPercentage() {
        List<Habit> allHabits = getAllHabits();
        if (allHabits.isEmpty()) return 0;

        int totalCompletion = 0;
        for (Habit habit : allHabits) {
            totalCompletion += habit.getProgressPercentage();
        }

        int average = totalCompletion / allHabits.size();
        return Math.min(average, 100);
    }

    public int getCompletionPercentageByCategory(String category) {
        List<Habit> categoryHabits = getHabitsByCategory(category);
        if (categoryHabits.isEmpty()) return 0;

        int totalCompletion = 0;
        for (Habit habit : categoryHabits) {
            totalCompletion += habit.getProgressPercentage();
        }

        int average = totalCompletion / categoryHabits.size();
        return Math.min(average, 100);
    }

    public int getCompletionPercentageByFrequency(String frequency) {
        List<Habit> frequencyHabits = getHabitsByFrequency(frequency);
        if (frequencyHabits.isEmpty()) return 0;

        int totalCompletion = 0;
        for (Habit habit : frequencyHabits) {
            totalCompletion += habit.getProgressPercentage();
        }

        int average = totalCompletion / frequencyHabits.size();
        return Math.min(average, 100);
    }

    // ==================== OTHER METHODS ====================

    public Habit getHabitById(String frequency, String habitTitle) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(frequency);
            for (Habit habit : habits) {
                if (habit.getTitle().equals(habitTitle)) {
                    return habit;
                }
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "Error getting habit by ID: " + e.getMessage(), e);
        }
        return null;
    }

    public void deleteHabit(Habit habit) {
        try {
            List<Habit> habits = getHabitsByFrequencyInternal(habit.getFrequency());
            int index = habits.indexOf(habit);
            if (index != -1) {
                String habitKey = getHabitKey(habit.getFrequency(), index);
                removeCheckCircleState(habitKey);
                habits.remove(habit);
                notifyHabitsChanged();
            }
        } catch (Exception e) {
            Log.e("HabitDataManager", "Error deleting habit by object: " + e.getMessage(), e);
        }
    }

    // ==================== INTERNAL METHODS ====================

    private List<Habit> getHabitsByFrequencyInternal(String frequency) {
        switch (frequency.toLowerCase()) {
            case "weekly": return weeklyHabits;
            case "monthly": return monthlyHabits;
            case "yearly": return yearlyHabits;
            case "daily":
            default: return dailyHabits;
        }
    }

    // ==================== LISTENER METHODS ====================

    public void setOnHabitsChangedListener(OnHabitsChangedListener listener) {
        this.habitsChangedListener = listener;
    }

    private void notifyHabitsChanged() {
        if (habitsChangedListener != null) {
            habitsChangedListener.onHabitsChanged();
        }
    }

    // ==================== DEBUG & RESET METHODS ====================

    public void debugPrintAllHabits() {
        Log.d("HabitDataManager", "=== CURRENT HABIT STATE ===");
        Log.d("HabitDataManager", "Daily: " + dailyHabits.size() + " habits");
        for (int i = 0; i < dailyHabits.size(); i++) {
            Habit h = dailyHabits.get(i);
            Log.d("HabitDataManager", "  [" + i + "] " + h.getTitle() + " - " + h.getFrequency() + " - " + h.getCompleted() + "/" + h.getTotal());
        }

        Log.d("HabitDataManager", "Weekly: " + weeklyHabits.size() + " habits");
        for (int i = 0; i < weeklyHabits.size(); i++) {
            Habit h = weeklyHabits.get(i);
            Log.d("HabitDataManager", "  [" + i + "] " + h.getTitle() + " - " + h.getFrequency() + " - " + h.getCompleted() + "/" + h.getTotal());
        }

        Log.d("HabitDataManager", "Monthly: " + monthlyHabits.size() + " habits");
        for (int i = 0; i < monthlyHabits.size(); i++) {
            Habit h = monthlyHabits.get(i);
            Log.d("HabitDataManager", "  [" + i + "] " + h.getTitle() + " - " + h.getFrequency() + " - " + h.getCompleted() + "/" + h.getTotal());
        }

        Log.d("HabitDataManager", "Yearly: " + yearlyHabits.size() + " habits");
        for (int i = 0; i < yearlyHabits.size(); i++) {
            Habit h = yearlyHabits.get(i);
            Log.d("HabitDataManager", "  [" + i + "] " + h.getTitle() + " - " + h.getFrequency() + " - " + h.getCompleted() + "/" + h.getTotal());
        }

        Log.d("HabitDataManager", "Check States: " + checkCircleStates.size() + " entries");
        for (String key : checkCircleStates.keySet()) {
            boolean[] states = checkCircleStates.get(key);
            int completed = 0;
            for (boolean state : states) {
                if (state) completed++;
            }
            Log.d("HabitDataManager", "  " + key + ": " + completed + "/" + states.length);
        }
        Log.d("HabitDataManager", "=== END CURRENT STATE ===");
    }

    public void clearAllData() {
        dailyHabits.clear();
        weeklyHabits.clear();
        monthlyHabits.clear();
        yearlyHabits.clear();
        checkCircleStates.clear();
        notifyHabitsChanged();
    }

    public void resetAllProgress() {
        for (Habit habit : getAllHabits()) {
            habit.setCompleted(0);
        }
        checkCircleStates.clear();
        initializeDefaultCheckCircleStates();
        notifyHabitsChanged();
    }
}