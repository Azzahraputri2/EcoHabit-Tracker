package com.example.ecohabit1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.content.DialogInterface;
import android.widget.Button;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;

public class HabitDetailActivity extends AppCompatActivity {

    private TextView txtTarget;
    private EditText edtHabitName;
    private TextView btnDaily, btnWeekly, btnMonthly, btnYearly;
    private TextView catWaste, catWater, catEnergy, catFood, catTransport, catShopping;
    private AppCompatButton btnSave, btnDelete;
    private ImageView btnBack, btnMinus, btnPlus;
    private Switch switchReminder;

    // Dynamic containers untuk multiple reminders
    private LinearLayout layoutDailyTimes;
    private LinearLayout layoutWeeklyDays;
    private LinearLayout layoutMonthlyDates;
    private LinearLayout layoutYearlyDates;

    // Time inputs untuk weekly, monthly, yearly
    private EditText edtHourWeekly, edtMinuteWeekly;
    private EditText edtHourMonthly, edtMinuteMonthly;
    private EditText edtHourYearly, edtMinuteYearly;

    // Lists untuk menyimpan reminder items
    private List<View> dailyTimeItems = new ArrayList<>();
    private List<View> weeklyDayItems = new ArrayList<>();
    private List<View> monthlyDateItems = new ArrayList<>();
    private List<View> yearlyDateItems = new ArrayList<>();

    private int target = 0;
    private String selectedFrequency = "daily";
    private String selectedCategory = "";
    private boolean isReminderEnabled = false;

    // Data untuk multiple reminders
    private List<String> dailyTimes = new ArrayList<>();
    private List<String> weeklyDays = new ArrayList<>();
    private List<String> monthlyDates = new ArrayList<>();
    private List<String> yearlyMonths = new ArrayList<>();
    private List<String> yearlyDates = new ArrayList<>();

    private Habit currentHabit;
    private int habitIndex;
    private String habitFrequency;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_habit_detail);

        try {
            // Get habit data from intent
            getHabitDataFromIntent();
            initializeViews();
            setupClickListeners();
            setupFrequencySelection();
            setupCategorySelection();
            setupReminderSwitch();
            populateHabitData();
            setupFooter();
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error in onCreate: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading habit details", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    // PERBAIKAN: Method untuk mendapatkan data habit dengan validasi check states
    private void getHabitDataFromIntent() {
        try {
            Intent intent = getIntent();
            if (intent != null) {
                habitFrequency = intent.getStringExtra("HABIT_FREQUENCY");
                habitIndex = intent.getIntExtra("HABIT_INDEX", -1);

                Log.d("HabitDetail", "Received data - Frequency: " + habitFrequency + ", Index: " + habitIndex);

                if (habitFrequency != null && habitIndex != -1) {
                    HabitDataManager dataManager = HabitDataManager.getInstance();

                    // PERBAIKAN: Gunakan method yang aman dengan check sync
                    currentHabit = dataManager.getHabitByFrequencyAndIndexWithCheckSync(habitFrequency, habitIndex);

                    if (currentHabit != null) {
                        Log.d("HabitDetail", "Loaded habit: " + currentHabit.getTitle() + " from " + habitFrequency);
                    } else {
                        Log.e("HabitDetail", "Habit not found at position: " + habitIndex);
                        Toast.makeText(this, "Error: Habit not found", Toast.LENGTH_LONG).show();
                        finish();
                    }
                } else {
                    Log.e("HabitDetail", "Missing habit data in intent");
                    Toast.makeText(this, "Error: Missing habit data", Toast.LENGTH_LONG).show();
                    finish();
                }
            }
        } catch (Exception e) {
            Log.e("HabitDetail", "Error loading habit: " + e.getMessage(), e);
            Toast.makeText(this, "Error loading habit: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
            finish();
        }
    }

    private List<Habit> getHabitsByFrequency(String frequency) {
        HabitDataManager dataManager = HabitDataManager.getInstance();
        switch (frequency) {
            case "daily": return dataManager.getDailyHabits();
            case "weekly": return dataManager.getWeeklyHabits();
            case "monthly": return dataManager.getMonthlyHabits();
            case "yearly": return dataManager.getYearlyHabits();
            default: return new ArrayList<>();
        }
    }

    private void initializeViews() {
        try {
            // Back button
            btnBack = findViewById(R.id.btnBack);

            // Habit name
            edtHabitName = findViewById(R.id.edtHabitName);

            // Frequency buttons
            btnDaily = findViewById(R.id.btnDaily);
            btnWeekly = findViewById(R.id.btnWeekly);
            btnMonthly = findViewById(R.id.btnMonthly);
            btnYearly = findViewById(R.id.btnYearly);

            // Target controls
            btnMinus = findViewById(R.id.btnMinus);
            btnPlus = findViewById(R.id.btnPlus);
            txtTarget = findViewById(R.id.txtTarget);

            // Category buttons
            catWaste = findViewById(R.id.catWaste);
            catWater = findViewById(R.id.catWater);
            catEnergy = findViewById(R.id.catEnergy);
            catFood = findViewById(R.id.catFood);
            catTransport = findViewById(R.id.catTransport);
            catShopping = findViewById(R.id.catShopping);

            // Reminder controls
            switchReminder = findViewById(R.id.switchReminder);

            // Dynamic containers
            layoutDailyTimes = findViewById(R.id.layoutDailyTimes);
            layoutWeeklyDays = findViewById(R.id.layoutWeeklyDays);
            layoutMonthlyDates = findViewById(R.id.layoutMonthlyDates);
            layoutYearlyDates = findViewById(R.id.layoutYearlyDates);

            // Time inputs untuk weekly, monthly, yearly
            edtHourWeekly = findViewById(R.id.edtHourWeekly);
            edtMinuteWeekly = findViewById(R.id.edtMinuteWeekly);
            edtHourMonthly = findViewById(R.id.edtHourMonthly);
            edtMinuteMonthly = findViewById(R.id.edtMinuteMonthly);
            edtHourYearly = findViewById(R.id.edtHourYearly);
            edtMinuteYearly = findViewById(R.id.edtMinuteYearly);

            // Action buttons
            btnSave = findViewById(R.id.btnSave);
            btnDelete = findViewById(R.id.btnDelete);
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error initializing views: " + e.getMessage(), e);
            throw e;
        }
    }

    private void populateHabitData() {
        if (currentHabit == null) return;

        try {
            // Set habit name
            edtHabitName.setText(currentHabit.getTitle());

            // Set frequency
            selectedFrequency = currentHabit.getFrequency();
            updateFrequencyUI(getFrequencyTextView(selectedFrequency));

            // Set target
            target = currentHabit.getTotal();
            updateTargetDisplay();

            // Set category
            selectedCategory = currentHabit.getCategory();
            selectCategory(selectedCategory);

            // Set reminder
            isReminderEnabled = hasReminder();
            switchReminder.setChecked(isReminderEnabled);

            // Load multiple reminders data
            loadReminderData();

            // Update UI
            updateReminderUI();
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error populating habit data: " + e.getMessage(), e);
        }
    }

    private boolean hasReminder() {
        return currentHabit != null && (
                !TextUtils.isEmpty(currentHabit.getReminderTime()) ||
                        (currentHabit.getReminderTimes() != null && !currentHabit.getReminderTimes().isEmpty()) ||
                        (currentHabit.getReminderDays() != null && !currentHabit.getReminderDays().isEmpty()) ||
                        (currentHabit.getReminderDates() != null && !currentHabit.getReminderDates().isEmpty()) ||
                        (currentHabit.getReminderMonths() != null && !currentHabit.getReminderMonths().isEmpty()) ||
                        (currentHabit.getReminderYearlyDates() != null && !currentHabit.getReminderYearlyDates().isEmpty())
        );
    }

    private void loadReminderData() {
        if (currentHabit == null) return;

        try {
            // Load data dari habit
            dailyTimes = currentHabit.getReminderTimes() != null ?
                    new ArrayList<>(currentHabit.getReminderTimes()) : new ArrayList<>();
            weeklyDays = currentHabit.getReminderDays() != null ?
                    new ArrayList<>(currentHabit.getReminderDays()) : new ArrayList<>();
            monthlyDates = currentHabit.getReminderDates() != null ?
                    new ArrayList<>(currentHabit.getReminderDates()) : new ArrayList<>();
            yearlyMonths = currentHabit.getReminderMonths() != null ?
                    new ArrayList<>(currentHabit.getReminderMonths()) : new ArrayList<>();
            yearlyDates = currentHabit.getReminderYearlyDates() != null ?
                    new ArrayList<>(currentHabit.getReminderYearlyDates()) : new ArrayList<>();

            // Set time jika ada
            if (!TextUtils.isEmpty(currentHabit.getReminderTime())) {
                String[] timeParts = currentHabit.getReminderTime().split(":");
                if (timeParts.length == 2) {
                    // Set time berdasarkan frequency
                    switch (selectedFrequency) {
                        case "weekly":
                            edtHourWeekly.setText(timeParts[0]);
                            edtMinuteWeekly.setText(timeParts[1]);
                            break;
                        case "monthly":
                            edtHourMonthly.setText(timeParts[0]);
                            edtMinuteMonthly.setText(timeParts[1]);
                            break;
                        case "yearly":
                            edtHourYearly.setText(timeParts[0]);
                            edtMinuteYearly.setText(timeParts[1]);
                            break;
                    }
                }
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error loading reminder data: " + e.getMessage(), e);
        }
    }

    private TextView getFrequencyTextView(String frequency) {
        switch (frequency) {
            case "daily": return btnDaily;
            case "weekly": return btnWeekly;
            case "monthly": return btnMonthly;
            case "yearly": return btnYearly;
            default: return btnDaily;
        }
    }

    private void selectCategory(String category) {
        try {
            // Reset semua kategori
            resetAllCategoryBackgrounds();

            // Set kategori yang dipilih dengan warna dark
            TextView selectedView = null;
            int darkColor = R.color.cat_waste_dark;

            switch (category) {
                case "Waste Reduction":
                    selectedView = catWaste;
                    darkColor = R.color.cat_waste_dark;
                    break;
                case "Water Conservation":
                    selectedView = catWater;
                    darkColor = R.color.cat_water_dark;
                    break;
                case "Energy Saving":
                    selectedView = catEnergy;
                    darkColor = R.color.cat_energy_dark;
                    break;
                case "Food Sustainability":
                    selectedView = catFood;
                    darkColor = R.color.cat_food_dark;
                    break;
                case "Transportation":
                    selectedView = catTransport;
                    darkColor = R.color.cat_transport_dark;
                    break;
                case "Shopping":
                    selectedView = catShopping;
                    darkColor = R.color.cat_shopping_dark;
                    break;
            }

            if (selectedView != null) {
                selectedView.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(this, darkColor)));
                selectedView.setTextColor(ContextCompat.getColor(this, R.color.white));
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error selecting category: " + e.getMessage(), e);
        }
    }

    private void setupClickListeners() {
        // Back button - Kembali ke sebelumnya
        btnBack.setOnClickListener(v -> {
            if (hasUnsavedChanges()) {
                showUnsavedChangesDialog();
            } else {
                finish();
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            }
        });

        // Target controls
        btnMinus.setOnClickListener(v -> decreaseTarget());
        btnPlus.setOnClickListener(v -> increaseTarget());

        // Delete button
        btnDelete.setOnClickListener(v -> deleteHabit());

        // Save button
        btnSave.setOnClickListener(v -> updateHabit());
    }

    private boolean hasUnsavedChanges() {
        if (currentHabit == null) return false;

        try {
            // Check if habit name changed
            if (!edtHabitName.getText().toString().trim().equals(currentHabit.getTitle())) {
                return true;
            }

            // Check if target changed
            if (target != currentHabit.getTotal()) {
                return true;
            }

            // Check if frequency changed
            if (!selectedFrequency.equals(currentHabit.getFrequency())) {
                return true;
            }

            // Check if category changed
            if (!selectedCategory.equals(currentHabit.getCategory())) {
                return true;
            }

            // Check if reminder settings changed
            if (isReminderEnabled != hasReminder()) {
                return true;
            }

            return false;
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error checking unsaved changes: " + e.getMessage(), e);
            return false;
        }
    }

    private void showUnsavedChangesDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Unsaved Changes");
        builder.setMessage("You have unsaved changes. Are you sure you want to leave?");

        builder.setNegativeButton("Stay", (dialog, which) -> dialog.dismiss());
        builder.setPositiveButton("Leave", (dialog, which) -> {
            finish();
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        AlertDialog dialog = builder.create();
        dialog.show();

        Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

        negativeButton.setTextColor(ContextCompat.getColor(this, R.color.text_gray));
        positiveButton.setTextColor(ContextCompat.getColor(this, R.color.delete_red));
    }

    private void setupReminderSwitch() {
        switchReminder.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                isReminderEnabled = isChecked;
                updateReminderUI();
            }
        });
    }

    private void updateReminderUI() {
        try {
            if (!isReminderEnabled) {
                clearAllReminderItems();
                hideAllReminderSections();
                return;
            }

            showReminderSectionForFrequency();

            switch (selectedFrequency) {
                case "daily":
                    setupDailyReminders();
                    break;
                case "weekly":
                    setupWeeklyReminders();
                    break;
                case "monthly":
                    setupMonthlyReminders();
                    break;
                case "yearly":
                    setupYearlyReminders();
                    break;
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error updating reminder UI: " + e.getMessage(), e);
        }
    }

    private void showReminderSectionForFrequency() {
        hideAllReminderSections();

        if (!isReminderEnabled) return;

        switch (selectedFrequency) {
            case "daily":
                findViewById(R.id.layoutDaily).setVisibility(View.VISIBLE);
                break;
            case "weekly":
                findViewById(R.id.layoutWeekly).setVisibility(View.VISIBLE);
                findViewById(R.id.layoutTimeWeekly).setVisibility(View.VISIBLE);
                break;
            case "monthly":
                findViewById(R.id.layoutMonthly).setVisibility(View.VISIBLE);
                findViewById(R.id.layoutTimeMonthly).setVisibility(View.VISIBLE);
                break;
            case "yearly":
                findViewById(R.id.layoutYearly).setVisibility(View.VISIBLE);
                findViewById(R.id.layoutTimeYearly).setVisibility(View.VISIBLE);
                break;
        }
    }

    private void hideAllReminderSections() {
        findViewById(R.id.layoutDaily).setVisibility(View.GONE);
        findViewById(R.id.layoutWeekly).setVisibility(View.GONE);
        findViewById(R.id.layoutMonthly).setVisibility(View.GONE);
        findViewById(R.id.layoutYearly).setVisibility(View.GONE);

        findViewById(R.id.layoutTimeWeekly).setVisibility(View.GONE);
        findViewById(R.id.layoutTimeMonthly).setVisibility(View.GONE);
        findViewById(R.id.layoutTimeYearly).setVisibility(View.GONE);
    }

    private void setupDailyReminders() {
        try {
            clearAllReminderItems();
            layoutDailyTimes.removeAllViews();
            dailyTimeItems.clear();

            // Ensure we have enough time slots
            while (dailyTimes.size() < target) {
                dailyTimes.add("");
            }

            for (int i = 0; i < target; i++) {
                View timeItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_daily, layoutDailyTimes, false);

                // Set label
                TextView label = timeItem.findViewById(R.id.textTimeLabel);
                if (label != null) {
                    label.setText("Time " + (i + 1) + " :");
                }

                // Setup time inputs dengan data yang ada
                EditText hourInput = timeItem.findViewById(R.id.edtHour);
                EditText minuteInput = timeItem.findViewById(R.id.edtMinute);

                // Set existing time data
                if (i < dailyTimes.size() && !TextUtils.isEmpty(dailyTimes.get(i))) {
                    String[] timeParts = dailyTimes.get(i).split(":");
                    if (timeParts.length == 2) {
                        hourInput.setText(timeParts[0]);
                        minuteInput.setText(timeParts[1]);
                    }
                }

                final int index = i;
                hourInput.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        saveDailyTime(index, hourInput.getText().toString(), minuteInput.getText().toString());
                    }
                });

                minuteInput.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        saveDailyTime(index, hourInput.getText().toString(), minuteInput.getText().toString());
                    }
                });

                layoutDailyTimes.addView(timeItem);
                dailyTimeItems.add(timeItem);
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up daily reminders: " + e.getMessage(), e);
        }
    }

    private void saveDailyTime(int index, String hour, String minute) {
        if (index < dailyTimes.size()) {
            String time = formatTime(hour, minute);
            dailyTimes.set(index, time);
        }
    }

    private void setupWeeklyReminders() {
        try {
            clearAllReminderItems();
            layoutWeeklyDays.removeAllViews();
            weeklyDayItems.clear();

            // Ensure we have enough day slots
            while (weeklyDays.size() < target) {
                weeklyDays.add("Monday");
            }

            // Day sections
            for (int i = 0; i < target; i++) {
                View dayItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_weekly, layoutWeeklyDays, false);

                // Set label
                TextView label = dayItem.findViewById(R.id.textDayLabel);
                if (label != null) {
                    label.setText("Day " + (i + 1) + " :");
                }

                // Setup spinner dengan data yang ada
                Spinner daySpinner = dayItem.findViewById(R.id.spinnerDay);
                setupDaySpinner(daySpinner, i);

                // Set existing selection
                if (i < weeklyDays.size()) {
                    setSpinnerSelection(daySpinner, weeklyDays.get(i));
                }

                layoutWeeklyDays.addView(dayItem);
                weeklyDayItems.add(dayItem);
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up weekly reminders: " + e.getMessage(), e);
        }
    }

    private void setupMonthlyReminders() {
        try {
            clearAllReminderItems();
            layoutMonthlyDates.removeAllViews();
            monthlyDateItems.clear();

            // Ensure we have enough date slots
            while (monthlyDates.size() < target) {
                monthlyDates.add("1");
            }

            // Date sections
            for (int i = 0; i < target; i++) {
                View dateItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_monthly, layoutMonthlyDates, false);

                // Set label
                TextView label = dateItem.findViewById(R.id.textDateLabel);
                if (label != null) {
                    label.setText("Date " + (i + 1) + " :");
                }

                // Setup spinner dengan data yang ada
                Spinner dateSpinner = dateItem.findViewById(R.id.spinnerDate);
                setupMonthlyDateSpinner(dateSpinner, i);

                // Set existing selection
                if (i < monthlyDates.size()) {
                    setSpinnerSelection(dateSpinner, monthlyDates.get(i));
                }

                layoutMonthlyDates.addView(dateItem);
                monthlyDateItems.add(dateItem);
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up monthly reminders: " + e.getMessage(), e);
        }
    }

    private void setupYearlyReminders() {
        try {
            clearAllReminderItems();
            layoutYearlyDates.removeAllViews();
            yearlyDateItems.clear();

            // Ensure we have enough slots
            while (yearlyMonths.size() < target) {
                yearlyMonths.add("January");
            }
            while (yearlyDates.size() < target) {
                yearlyDates.add("1");
            }

            // Month-Date sections
            for (int i = 0; i < target; i++) {
                View yearlyItem = getLayoutInflater().inflate(R.layout.layout_reminder_item_yearly, layoutYearlyDates, false);

                // Setup spinners dengan data yang ada
                Spinner monthSpinner = yearlyItem.findViewById(R.id.spinnerMonth);
                Spinner dateSpinner = yearlyItem.findViewById(R.id.spinnerDate);

                setupYearlyMonthSpinner(monthSpinner, i);
                setupYearlyDateSpinner(dateSpinner, i);

                // Set existing selections
                if (i < yearlyMonths.size()) {
                    setSpinnerSelection(monthSpinner, yearlyMonths.get(i));
                }
                if (i < yearlyDates.size()) {
                    setSpinnerSelection(dateSpinner, yearlyDates.get(i));
                }

                layoutYearlyDates.addView(yearlyItem);
                yearlyDateItems.add(yearlyItem);
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up yearly reminders: " + e.getMessage(), e);
        }
    }

    private void clearAllReminderItems() {
        layoutDailyTimes.removeAllViews();
        layoutWeeklyDays.removeAllViews();
        layoutMonthlyDates.removeAllViews();
        layoutYearlyDates.removeAllViews();

        dailyTimeItems.clear();
        weeklyDayItems.clear();
        monthlyDateItems.clear();
        yearlyDateItems.clear();
    }

    private void setupDaySpinner(Spinner spinner, final int index) {
        try {
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this,
                    R.array.days_of_week,
                    android.R.layout.simple_spinner_item
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);

            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (index < weeklyDays.size()) {
                        weeklyDays.set(index, parent.getItemAtPosition(position).toString());
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    if (index < weeklyDays.size()) {
                        weeklyDays.set(index, "Monday");
                    }
                }
            });
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up day spinner: " + e.getMessage(), e);
        }
    }

    private void setupMonthlyDateSpinner(Spinner spinner, final int index) {
        try {
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this,
                    R.array.monthly_dates,
                    android.R.layout.simple_spinner_item
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);

            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (index < monthlyDates.size()) {
                        monthlyDates.set(index, parent.getItemAtPosition(position).toString());
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    if (index < monthlyDates.size()) {
                        monthlyDates.set(index, "1");
                    }
                }
            });
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up monthly date spinner: " + e.getMessage(), e);
        }
    }

    private void setupYearlyMonthSpinner(Spinner spinner, final int index) {
        try {
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this,
                    R.array.months_of_year,
                    android.R.layout.simple_spinner_item
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);

            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (index < yearlyMonths.size()) {
                        yearlyMonths.set(index, parent.getItemAtPosition(position).toString());
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    if (index < yearlyMonths.size()) {
                        yearlyMonths.set(index, "January");
                    }
                }
            });
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up yearly month spinner: " + e.getMessage(), e);
        }
    }

    private void setupYearlyDateSpinner(Spinner spinner, final int index) {
        try {
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                    this,
                    R.array.monthly_dates,
                    android.R.layout.simple_spinner_item
            );
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);

            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (index < yearlyDates.size()) {
                        yearlyDates.set(index, parent.getItemAtPosition(position).toString());
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    if (index < yearlyDates.size()) {
                        yearlyDates.set(index, "1");
                    }
                }
            });
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting up yearly date spinner: " + e.getMessage(), e);
        }
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        try {
            for (int i = 0; i < spinner.getCount(); i++) {
                if (spinner.getItemAtPosition(i).toString().equals(value)) {
                    spinner.setSelection(i);
                    break;
                }
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error setting spinner selection: " + e.getMessage(), e);
        }
    }

    private void setupFrequencySelection() {
        View.OnClickListener frequencyListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    updateFrequencyUI((TextView) v);

                    if (v.getId() == R.id.btnDaily) {
                        selectedFrequency = "daily";
                    } else if (v.getId() == R.id.btnWeekly) {
                        selectedFrequency = "weekly";
                    } else if (v.getId() == R.id.btnMonthly) {
                        selectedFrequency = "monthly";
                    } else if (v.getId() == R.id.btnYearly) {
                        selectedFrequency = "yearly";
                    }

                    updateReminderUI();
                } catch (Exception e) {
                    Log.e("HabitDetailActivity", "Error in frequency selection: " + e.getMessage(), e);
                }
            }
        };

        btnDaily.setOnClickListener(frequencyListener);
        btnWeekly.setOnClickListener(frequencyListener);
        btnMonthly.setOnClickListener(frequencyListener);
        btnYearly.setOnClickListener(frequencyListener);
    }

    private void updateFrequencyUI(TextView selectedView) {
        try {
            btnDaily.setBackgroundResource(R.drawable.bg_frequency_unselected);
            btnWeekly.setBackgroundResource(R.drawable.bg_frequency_unselected);
            btnMonthly.setBackgroundResource(R.drawable.bg_frequency_unselected);
            btnYearly.setBackgroundResource(R.drawable.bg_frequency_unselected);

            btnDaily.setTextColor(ContextCompat.getColor(this, R.color.frequency_unselected_text));
            btnWeekly.setTextColor(ContextCompat.getColor(this, R.color.frequency_unselected_text));
            btnMonthly.setTextColor(ContextCompat.getColor(this, R.color.frequency_unselected_text));
            btnYearly.setTextColor(ContextCompat.getColor(this, R.color.frequency_unselected_text));

            selectedView.setBackgroundResource(R.drawable.bg_frequency_selected);
            selectedView.setTextColor(ContextCompat.getColor(this, R.color.frequency_selected_text));
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error updating frequency UI: " + e.getMessage(), e);
        }
    }

    private void setupCategorySelection() {
        View.OnClickListener categoryListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    resetAllCategoryBackgrounds();

                    TextView selectedCategoryView = (TextView) v;
                    int darkColor = getDarkColorForCategory(selectedCategoryView.getText().toString());
                    selectedCategoryView.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            ContextCompat.getColor(HabitDetailActivity.this, darkColor)));
                    selectedCategoryView.setTextColor(ContextCompat.getColor(HabitDetailActivity.this, R.color.white));

                    selectedCategory = selectedCategoryView.getText().toString();
                } catch (Exception e) {
                    Log.e("HabitDetailActivity", "Error in category selection: " + e.getMessage(), e);
                }
            }
        };

        catWaste.setOnClickListener(categoryListener);
        catWater.setOnClickListener(categoryListener);
        catEnergy.setOnClickListener(categoryListener);
        catFood.setOnClickListener(categoryListener);
        catTransport.setOnClickListener(categoryListener);
        catShopping.setOnClickListener(categoryListener);
    }

    private void resetAllCategoryBackgrounds() {
        try {
            TextView[] categoryViews = {catWaste, catWater, catEnergy, catFood, catTransport, catShopping};
            int[] colors = {R.color.cat_waste, R.color.cat_water, R.color.cat_energy,
                    R.color.cat_food, R.color.cat_transport, R.color.cat_shopping};

            for (int i = 0; i < categoryViews.length; i++) {
                categoryViews[i].setBackgroundResource(R.drawable.bg_category);
                categoryViews[i].setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(this, colors[i])));
                categoryViews[i].setTextColor(ContextCompat.getColor(this, R.color.white));
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error resetting category backgrounds: " + e.getMessage(), e);
        }
    }

    private int getDarkColorForCategory(String category) {
        switch (category) {
            case "Waste Reduction": return R.color.cat_waste_dark;
            case "Water Conservation": return R.color.cat_water_dark;
            case "Energy Saving": return R.color.cat_energy_dark;
            case "Food Sustainability": return R.color.cat_food_dark;
            case "Transportation": return R.color.cat_transport_dark;
            case "Shopping": return R.color.cat_shopping_dark;
            default: return R.color.cat_waste_dark;
        }
    }

    private void increaseTarget() {
        target++;
        updateTargetDisplay();
        updateReminderUI();
    }

    private void decreaseTarget() {
        if (target > 0) {
            target--;
            updateTargetDisplay();
            updateReminderUI();
        }
    }

    private void updateTargetDisplay() {
        txtTarget.setText(String.valueOf(target));
    }

    // PERBAIKAN: Method updateHabit yang lebih aman
    private void updateHabit() {
        try {
            String habitName = edtHabitName.getText().toString().trim();

            // AMBIL WAKTU DARI INPUT YANG SESUAI DENGAN FREQUENCY
            String hour = "";
            String minute = "";

            if (isReminderEnabled) {
                switch (selectedFrequency) {
                    case "weekly":
                        hour = edtHourWeekly.getText().toString().trim();
                        minute = edtMinuteWeekly.getText().toString().trim();
                        break;
                    case "monthly":
                        hour = edtHourMonthly.getText().toString().trim();
                        minute = edtMinuteMonthly.getText().toString().trim();
                        break;
                    case "yearly":
                        hour = edtHourYearly.getText().toString().trim();
                        minute = edtMinuteYearly.getText().toString().trim();
                        break;
                    default: // daily - tidak perlu waktu global
                        break;
                }
            }

            // Validation
            if (TextUtils.isEmpty(habitName)) {
                showToast("Please enter habit name");
                return;
            }

            if (target == 0) {
                showToast("Please set target per period");
                return;
            }

            if (TextUtils.isEmpty(selectedCategory)) {
                showToast("Please select a category");
                return;
            }

            if (isReminderEnabled && !validateReminders()) {
                return;
            }

            Log.d("HabitDetail", "Updating habit - Old Frequency: " + habitFrequency +
                    ", New Frequency: " + selectedFrequency + ", Index: " + habitIndex);

            // PERBAIKAN: Gunakan method update yang aman
            boolean success = updateHabitObjectSafely(habitName, hour, minute);

            if (success) {
                showToast("Habit '" + habitName + "' updated successfully!");
                navigateToMainActivity();
            } else {
                showToast("Error updating habit. Please try again.");
            }

        } catch (Exception e) {
            Log.e("HabitDetail", "Error updating habit: " + e.getMessage(), e);
            e.printStackTrace();
            showToast("Error updating habit: " + e.getMessage());

            // Fallback: Coba kembali ke main activity
            try {
                navigateToMainActivity();
            } catch (Exception ex) {
                Log.e("HabitDetail", "Error navigating to main: " + ex.getMessage());
                finish();
            }
        }
    }

    // PERBAIKAN: Method update yang lebih aman
    private boolean updateHabitObjectSafely(String habitName, String hour, String minute) {
        try {
            String reminderTime = "";
            List<String> reminderTimes = new ArrayList<>();
            List<String> reminderDays = new ArrayList<>();
            List<String> reminderDates = new ArrayList<>();
            List<String> reminderMonths = new ArrayList<>();
            List<String> reminderYearlyDates = new ArrayList<>();

            if (isReminderEnabled) {
                switch (selectedFrequency) {
                    case "daily":
                        reminderTimes = new ArrayList<>(dailyTimes);
                        break;
                    case "weekly":
                        reminderTime = formatTime(hour, minute);
                        reminderDays = new ArrayList<>(weeklyDays);
                        break;
                    case "monthly":
                        reminderTime = formatTime(hour, minute);
                        reminderDates = new ArrayList<>(monthlyDates);
                        break;
                    case "yearly":
                        reminderTime = formatTime(hour, minute);
                        reminderMonths = new ArrayList<>(yearlyMonths);
                        reminderYearlyDates = new ArrayList<>(yearlyDates);
                        break;
                }
            }

            // Buat habit baru dengan data yang di-update
            Habit updatedHabit = new Habit(
                    habitName,
                    currentHabit.getCompleted(), // Keep existing completed count
                    target, // Updated target
                    getColorForCategory(selectedCategory),
                    selectedFrequency, // Gunakan selectedFrequency yang baru
                    selectedCategory,
                    reminderTime,
                    currentHabit.getNotes() != null ? currentHabit.getNotes() : "", // notes
                    "", // single reminder day (deprecated)
                    "", // single reminder monthly date (deprecated)
                    "", // single reminder yearly month (deprecated)
                    ""  // single reminder yearly date (deprecated)
            );

            // Set multiple reminders
            updatedHabit.setReminderTimes(reminderTimes);
            updatedHabit.setReminderDays(reminderDays);
            updatedHabit.setReminderDates(reminderDates);
            updatedHabit.setReminderMonths(reminderMonths);
            updatedHabit.setReminderYearlyDates(reminderYearlyDates);

            // PERBAIKAN: Gunakan method update yang aman dari HabitDataManager
            HabitDataManager dataManager = HabitDataManager.getInstance();
            return dataManager.safeUpdateHabit(habitFrequency, habitIndex, updatedHabit);

        } catch (Exception e) {
            Log.e("HabitDetail", "Error in updateHabitObjectSafely: " + e.getMessage(), e);
            return false;
        }
    }

    private boolean validateReminders() {
        try {
            switch (selectedFrequency) {
                case "daily": return validateDailyReminders();
                case "weekly": return validateWeeklyReminders();
                case "monthly": return validateMonthlyReminders();
                case "yearly": return validateYearlyReminders();
                default: return true;
            }
        } catch (Exception e) {
            Log.e("HabitDetailActivity", "Error validating reminders: " + e.getMessage(), e);
            return false;
        }
    }

    private boolean validateDailyReminders() {
        for (int i = 0; i < dailyTimes.size(); i++) {
            String time = dailyTimes.get(i);
            if (TextUtils.isEmpty(time)) {
                showToast("Please enter time for reminder " + (i + 1));
                return false;
            }
        }
        return true;
    }

    private boolean validateWeeklyReminders() {
        String hour = edtHourWeekly.getText().toString().trim();
        String minute = edtMinuteWeekly.getText().toString().trim();
        if (!isValidTime(hour, minute)) {
            showToast("Please enter valid time (00-23 for hour, 00-59 for minute)");
            return false;
        }
        return true;
    }

    private boolean validateMonthlyReminders() {
        String hour = edtHourMonthly.getText().toString().trim();
        String minute = edtMinuteMonthly.getText().toString().trim();
        if (!isValidTime(hour, minute)) {
            showToast("Please enter valid time (00-23 for hour, 00-59 for minute)");
            return false;
        }
        return true;
    }

    private boolean validateYearlyReminders() {
        String hour = edtHourYearly.getText().toString().trim();
        String minute = edtMinuteYearly.getText().toString().trim();
        if (!isValidTime(hour, minute)) {
            showToast("Please enter valid time (00-23 for hour, 00-59 for minute)");
            return false;
        }
        return true;
    }

    private void deleteHabit() {
        if (currentHabit != null) {
            showDeleteConfirmationDialog(currentHabit.getTitle());
        }
    }

    private void showDeleteConfirmationDialog(String habitName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Habit");
        builder.setMessage("Delete \"" + habitName + "\"? This action cannot be undone.");

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.setPositiveButton("Delete", (dialog, which) -> executeDeleteHabit());

        AlertDialog dialog = builder.create();
        dialog.show();

        Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

        negativeButton.setTextColor(ContextCompat.getColor(this, R.color.text_gray));
        positiveButton.setTextColor(ContextCompat.getColor(this, R.color.delete_red));
    }

    // PERBAIKAN: Method executeDeleteHabit yang lebih aman
    private void executeDeleteHabit() {
        if (currentHabit != null) {
            HabitDataManager dataManager = HabitDataManager.getInstance();
            boolean success = dataManager.safeDeleteHabit(habitFrequency, habitIndex);

            if (success) {
                showDeleteSuccessDialog(currentHabit.getTitle());
            } else {
                showToast("Error deleting habit. Please try again.");
            }
        }
    }

    private void showDeleteSuccessDialog(String habitName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Habit Deleted");
        builder.setMessage("Habit \"" + habitName + "\" has been deleted successfully.");
        builder.setPositiveButton("OK", (dialog, which) -> navigateToMainActivity());
        builder.setCancelable(false);
        builder.show();
    }

    private boolean isValidTime(String hour, String minute) {
        if (!isReminderEnabled) return true;
        if (TextUtils.isEmpty(hour) && TextUtils.isEmpty(minute)) return false;

        try {
            int h = Integer.parseInt(hour);
            int m = Integer.parseInt(minute);
            return (h >= 0 && h <= 23) && (m >= 0 && m <= 59);
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private String formatTime(String hour, String minute) {
        if (TextUtils.isEmpty(hour) && TextUtils.isEmpty(minute)) return "";

        int h = TextUtils.isEmpty(hour) ? 0 : Integer.parseInt(hour);
        int m = TextUtils.isEmpty(minute) ? 0 : Integer.parseInt(minute);
        return String.format("%02d:%02d", h, m);
    }

    private int getColorForCategory(String category) {
        switch (category) {
            case "Waste Reduction": return R.color.cat_waste;
            case "Water Conservation": return R.color.cat_water;
            case "Energy Saving": return R.color.cat_energy;
            case "Food Sustainability": return R.color.cat_food;
            case "Transportation": return R.color.cat_transport;
            case "Shopping": return R.color.cat_shopping;
            default: return R.color.cat_waste;
        }
    }

    private void navigateToMainActivity() {
        Intent intent = new Intent(HabitDetailActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        finish();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void setupFooter() {
        setFooterActive("habits");

        findViewById(R.id.footer_home).setOnClickListener(v -> navigateToMainActivity());
        findViewById(R.id.footer_habits).setOnClickListener(v -> {});
        findViewById(R.id.footer_profile).setOnClickListener(v -> {
            Intent intent = new Intent(HabitDetailActivity.this, ProfileActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });
    }

    private void setFooterActive(String activeTab) {
        int inactiveColor = ContextCompat.getColor(this, R.color.footer_inactive);
        int activeColor = ContextCompat.getColor(this, R.color.footer_active);

        ImageView iconHome = findViewById(R.id.icon_home);
        ImageView iconHabits = findViewById(R.id.icon_habits);
        ImageView iconProfile = findViewById(R.id.icon_profile);

        iconHome.setColorFilter(activeTab.equals("home") ? activeColor : inactiveColor);
        iconHabits.setColorFilter(activeTab.equals("habits") ? activeColor : inactiveColor);
        iconProfile.setColorFilter(activeTab.equals("profile") ? activeColor : inactiveColor);
    }
}