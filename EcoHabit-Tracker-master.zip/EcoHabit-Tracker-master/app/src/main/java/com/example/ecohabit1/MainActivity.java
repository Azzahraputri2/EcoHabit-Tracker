package com.example.ecohabit1;

import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements HabitDataManager.OnHabitsChangedListener {

    // UI Components
    private CardView cardAddHabit;
    private TextView textProgressPercentage;
    private TextView textCompletedCount;
    private ProgressBar circularProgress;
    private TextView textSeeAll;
    private TextView tabDaily, tabWeekly, tabMonthly, tabYearly;
    private TextView textEmptyState;

    // Habit TextViews
    private TextView completedCountHabit1, percentageHabit1;
    private TextView completedCountHabit2, percentageHabit2;
    private TextView completedCountHabit3, percentageHabit3;

    // Habit ProgressBars
    private ProgressBar progressHabit1, progressHabit2, progressHabit3;

    // PERBAIKAN: Ganti tipe Check containers menjadi FlexboxLayout
    private com.google.android.flexbox.FlexboxLayout checksContainerHabit1, checksContainerHabit2, checksContainerHabit3;

    // Color indicators
    private View colorIndicator1, colorIndicator2, colorIndicator3;

    // Habit Cards
    private CardView habitCard1, habitCard2, habitCard3;

    // Data Manager
    private HabitDataManager dataManager;

    // Current active tab
    private String currentTab = "daily";

    // PERBAIKAN: Deklarasi habitsChangedListener
    private HabitDataManager.OnHabitsChangedListener habitsChangedListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        View rootView = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dataManager = HabitDataManager.getInstance();

        // PERBAIKAN: Data sudah terinisialisasi di constructor HabitDataManager
        // Tidak perlu panggil ensureDefaultDataInitialized() lagi

        // PERBAIKAN: Inisialisasi listener
        habitsChangedListener = this;
        dataManager.setOnHabitsChangedListener(habitsChangedListener);

        initializeViews();
        setupClickListeners();
        setupTabListeners();
        setupFooter();
        showHabitsForTab("daily");

        Log.d("MainActivity", "✅ MainActivity created successfully");
    }

    private void initializeViews() {
        try {
            cardAddHabit = findViewById(R.id.cardAddHabit);
            textProgressPercentage = findViewById(R.id.textProgressPercentage);
            textCompletedCount = findViewById(R.id.textCompletedCount);
            circularProgress = findViewById(R.id.circularProgress);
            textSeeAll = findViewById(R.id.textSeeAll);
            tabDaily = findViewById(R.id.tabDaily);
            tabWeekly = findViewById(R.id.tabWeekly);
            tabMonthly = findViewById(R.id.tabMonthly);
            tabYearly = findViewById(R.id.tabYearly);
            textEmptyState = findViewById(R.id.textEmptyState);

            // Habit progress bars
            progressHabit1 = findViewById(R.id.progressHabit1);
            progressHabit2 = findViewById(R.id.progressHabit2);
            progressHabit3 = findViewById(R.id.progressHabit3);

            // PERBAIKAN: Initialize FlexboxLayout check containers
            checksContainerHabit1 = findViewById(R.id.checksContainerHabit1);
            checksContainerHabit2 = findViewById(R.id.checksContainerHabit2);
            checksContainerHabit3 = findViewById(R.id.checksContainerHabit3);

            // TextView untuk habit completion dan persentase
            completedCountHabit1 = findViewById(R.id.completedCountHabit1);
            percentageHabit1 = findViewById(R.id.percentageHabit1);
            completedCountHabit2 = findViewById(R.id.completedCountHabit2);
            percentageHabit2 = findViewById(R.id.percentageHabit2);
            completedCountHabit3 = findViewById(R.id.completedCountHabit3);
            percentageHabit3 = findViewById(R.id.percentageHabit3);

            // Initialize color indicators
            colorIndicator1 = findViewById(R.id.colorIndicator1);
            colorIndicator2 = findViewById(R.id.colorIndicator2);
            colorIndicator3 = findViewById(R.id.colorIndicator3);

            // Initialize habit cards
            habitCard1 = findViewById(R.id.habitCard1);
            habitCard2 = findViewById(R.id.habitCard2);
            habitCard3 = findViewById(R.id.habitCard3);

            Log.d("MainActivity", "✅ All views initialized successfully");
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error initializing views", e);
            Toast.makeText(this, "Error initializing app", Toast.LENGTH_SHORT).show();
        }
    }

    private void showHabitsForTab(String tab) {
        try {
            currentTab = tab;
            List<Habit> habitsToShow = getCurrentHabits();

            Log.d("MainActivity", "🔄 Showing habits for tab: " + tab + ", count: " + habitsToShow.size());

            if (habitsToShow.isEmpty()) {
                showEmptyState();
            } else {
                hideEmptyState();
                displayHabits(habitsToShow);
            }

            updateCircleChartForCurrentTab();
            updateTabSelection(tab);
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error showing habits for tab: " + tab, e);
            Toast.makeText(this, "Error loading habits", Toast.LENGTH_SHORT).show();
        }
    }

    // PERBAIKAN: Method untuk update tab selection
    private void updateTabSelection(String selectedTab) {
        try {
            // Reset all tabs
            TextView[] tabs = {tabDaily, tabWeekly, tabMonthly, tabYearly};
            int unselectedTextColor = ContextCompat.getColor(this, R.color.tab_unselected_text);
            int selectedTextColor = ContextCompat.getColor(this, R.color.tab_selected_text);

            for (TextView tab : tabs) {
                if (tab != null) {
                    tab.setBackgroundResource(R.drawable.tab_background);
                    tab.setTextColor(unselectedTextColor);
                }
            }

            // Set selected tab berdasarkan parameter
            TextView selectedTextView = null;
            switch (selectedTab) {
                case "daily":
                    selectedTextView = tabDaily;
                    break;
                case "weekly":
                    selectedTextView = tabWeekly;
                    break;
                case "monthly":
                    selectedTextView = tabMonthly;
                    break;
                case "yearly":
                    selectedTextView = tabYearly;
                    break;
            }

            if (selectedTextView != null) {
                selectedTextView.setBackgroundResource(R.drawable.tab_background_selected);
                selectedTextView.setTextColor(selectedTextColor);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating tab selection", e);
        }
    }

    private void showEmptyState() {
        try {
            hideHabit1();
            hideHabit2();
            hideHabit3();

            if (textEmptyState != null) {
                textEmptyState.setVisibility(View.VISIBLE);
            }

            Log.d("MainActivity", "ℹ️ Showing empty state for tab: " + currentTab);
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error showing empty state", e);
        }
    }

    private void hideEmptyState() {
        try {
            if (textEmptyState != null) {
                textEmptyState.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error hiding empty state", e);
        }
    }

    private void displayHabits(List<Habit> habits) {
        try {
            // Reset semua habit card
            hideHabit1();
            hideHabit2();
            hideHabit3();

            // Tampilkan maksimal 3 habit
            int count = Math.min(habits.size(), 3);
            Log.d("MainActivity", "🔄 Displaying " + count + " habits for tab: " + currentTab);

            for (int i = 0; i < count; i++) {
                Habit habit = habits.get(i);
                int dataIndex = i; // Index dalam list yang sedang ditampilkan

                Log.d("MainActivity", "📝 Habit " + (i + 1) + ": " + habit.getTitle() +
                        " (" + habit.getCompleted() + "/" + habit.getTotal() + ")");

                if (i == 0) {
                    displayHabit1(habit, dataIndex);
                } else if (i == 1) {
                    displayHabit2(habit, dataIndex);
                } else if (i == 2) {
                    displayHabit3(habit, dataIndex);
                }
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error displaying habits", e);
        }
    }

    private void displayHabit1(Habit habit, int habitIndex) {
        try {
            setupHabitCard(habitCard1, habit, habitIndex,
                    R.id.habitTitle1, colorIndicator1,
                    progressHabit1, percentageHabit1,
                    checksContainerHabit1, completedCountHabit1,
                    1, habitIndex);
            Log.d("MainActivity", "✅ Habit 1 displayed: " + habit.getTitle());
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error displaying habit 1", e);
        }
    }

    private void displayHabit2(Habit habit, int habitIndex) {
        try {
            setupHabitCard(habitCard2, habit, habitIndex,
                    R.id.habitTitle2, colorIndicator2,
                    progressHabit2, percentageHabit2,
                    checksContainerHabit2, completedCountHabit2,
                    2, habitIndex);
            Log.d("MainActivity", "✅ Habit 2 displayed: " + habit.getTitle());
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error displaying habit 2", e);
        }
    }

    private void displayHabit3(Habit habit, int habitIndex) {
        try {
            setupHabitCard(habitCard3, habit, habitIndex,
                    R.id.habitTitle3, colorIndicator3,
                    progressHabit3, percentageHabit3,
                    checksContainerHabit3, completedCountHabit3,
                    3, habitIndex);
            Log.d("MainActivity", "✅ Habit 3 displayed: " + habit.getTitle());
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error displaying habit 3", e);
        }
    }

    // Method terpusat untuk setup habit card - PERBAIKAN: Update parameter untuk FlexboxLayout
    private void setupHabitCard(CardView habitCard, Habit habit, int habitIndex,
                                int titleId, View colorIndicator,
                                ProgressBar progressBar, TextView percentageText,
                                com.google.android.flexbox.FlexboxLayout checksContainer, TextView completedCountText,
                                int habitNumber, int dataIndex) {

        try {
            // Set habit title
            TextView habitTitle = findViewById(titleId);
            if (habitTitle != null) {
                habitTitle.setText(habit.getTitle());
            }

            // Update color indicator dengan warna kategori yang benar
            if (colorIndicator != null) {
                int colorRes = getColorResForCategory(habit.getCategory());
                colorIndicator.setBackgroundColor(ContextCompat.getColor(this, colorRes));
            }

            // Update progress bar dengan warna yang benar
            if (progressBar != null) {
                progressBar.setProgress(habit.getProgressPercentage());
                int colorRes = getColorResForCategory(habit.getCategory());
                updateProgressBarColor(progressBar, colorRes);
            }

            // Update text color dengan warna yang benar
            if (percentageText != null) {
                int colorRes = getColorResForCategory(habit.getCategory());
                percentageText.setTextColor(ContextCompat.getColor(this, colorRes));
            }

            // PERBAIKAN: Sync check circles dengan data habit yang benar
            if (checksContainer != null) {
                syncCheckCirclesWithHabit(checksContainer, habit, habitNumber, dataIndex);
            }

            // Update text
            updateHabitText(habitNumber, habit.getCompleted(), habit.getTotal());

            // Set click listener untuk habit card
            if (habitCard != null) {
                habitCard.setOnClickListener(v -> openHabitDetail(currentTab, dataIndex));
            }

            // Show habit card
            if (habitCard != null) {
                habitCard.setVisibility(View.VISIBLE);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error setting up habit card " + habitNumber, e);
        }
    }

    // PERBAIKAN BESAR: Method untuk sync check circles dengan FlexboxLayout
    private void syncCheckCirclesWithHabit(com.google.android.flexbox.FlexboxLayout container, Habit habit, int habitNumber, int habitIndex) {
        try {
            container.removeAllViews();

            // PERBAIKAN: Pastikan check states konsisten sebelum mengambil
            dataManager.ensureCheckStatesConsistencyForHabit(currentTab, habitIndex, habit);

            // PERBAIKAN: Gunakan data dari HabitDataManager untuk sinkronisasi
            String habitKey = dataManager.getHabitKey(currentTab, habitIndex);
            boolean[] checkStates = dataManager.getCheckCircleState(habitKey);

            // PERBAIKAN: Jika tidak ada state yang disimpan, buat state baru berdasarkan completed count
            if (checkStates == null || checkStates.length != habit.getTotal()) {
                Log.d("MainActivity", "🔄 Creating new check states for: " + habit.getTitle() +
                        " (total: " + habit.getTotal() + ", completed: " + habit.getCompleted() + ")");

                checkStates = new boolean[habit.getTotal()];
                for (int i = 0; i < habit.getTotal(); i++) {
                    checkStates[i] = i < habit.getCompleted();
                }
                // Simpan state awal ke HabitDataManager
                dataManager.saveCheckCircleState(habitKey, checkStates);
            }

            // PERBAIKAN: Validasi jika habit baru harus memiliki state kosong
            if (habit.getCompleted() == 0) {
                boolean allFalse = true;
                for (boolean state : checkStates) {
                    if (state) {
                        allFalse = false;
                        break;
                    }
                }

                // Jika ada yang true padahal completed = 0, reset state
                if (!allFalse) {
                    Log.d("MainActivity", "🔄 Resetting check states for NEW habit: " + habit.getTitle());
                    for (int i = 0; i < checkStates.length; i++) {
                        checkStates[i] = false;
                    }
                    dataManager.saveCheckCircleState(habitKey, checkStates);
                    // Pastikan completed count tetap 0
                    habit.setCompleted(0);
                }
            }

            for (int i = 0; i < habit.getTotal(); i++) {
                ImageView checkCircle = createConsistentCheckCircle(habit, i, habitNumber, habitIndex);

                // PERBAIKAN: Gunakan ukuran 32dp yang KONSISTEN dengan XML
                com.google.android.flexbox.FlexboxLayout.LayoutParams params = new com.google.android.flexbox.FlexboxLayout.LayoutParams(
                        dpToPx(32), // UKURAN KONSISTEN 32dp sesuai dengan XML
                        dpToPx(32)  // UKURAN KONSISTEN 32dp sesuai dengan XML
                );
                params.setMargins(0, 0, dpToPx(8), dpToPx(8)); // Margin yang konsisten dengan XML
                checkCircle.setLayoutParams(params);

                container.addView(checkCircle);

                // PERBAIKAN: Gunakan state dari HabitDataManager
                boolean isCompleted = i < checkStates.length ? checkStates[i] : (i < habit.getCompleted());
                updateCheckVisual(checkCircle, isCompleted);
                checkCircle.setTag(isCompleted);
            }

            // PERBAIKAN: Validasi konsistensi antara completed count dan check states
            validateAndSyncCheckStates(container, habit, habitIndex);

            Log.d("MainActivity", "✅ Check circles synced for: " + habit.getTitle() +
                    " (" + habit.getCompleted() + "/" + habit.getTotal() + ")");
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error syncing check circles for: " + habit.getTitle(), e);
        }
    }

    // PERBAIKAN BARU: Method untuk validasi dan sinkronisasi state check circles
    private void validateAndSyncCheckStates(com.google.android.flexbox.FlexboxLayout container, Habit habit, int habitIndex) {
        try {
            String habitKey = dataManager.getHabitKey(currentTab, habitIndex);
            boolean[] checkStates = dataManager.getCheckCircleState(habitKey);

            if (checkStates != null) {
                int actualCompleted = 0;
                for (boolean state : checkStates) {
                    if (state) actualCompleted++;
                }

                // Jika ada perbedaan antara completed count dan actual check states, sync
                if (actualCompleted != habit.getCompleted()) {
                    Log.d("MainActivity", "🔄 Syncing check states: " + habit.getCompleted() + " -> " + actualCompleted);
                    habit.setCompleted(actualCompleted);
                    dataManager.updateHabitProgress(currentTab, habitIndex, actualCompleted);
                    updateCircleChartForCurrentTab();
                }
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error validating check states", e);
        }
    }

    // PERBAIKAN: Method baru untuk membuat check circle dengan styling yang KONSISTEN
    private ImageView createConsistentCheckCircle(Habit habit, int checkIndex, int habitNumber, int habitIndex) {
        ImageView checkCircle = new ImageView(this);

        // PERBAIKAN: Styling yang KONSISTEN
        checkCircle.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        checkCircle.setClickable(true);
        checkCircle.setFocusable(true);

        // PERBAIKAN: Setup click listener dengan update yang benar
        checkCircle.setOnClickListener(v -> {
            try {
                boolean currentlyFilled = checkCircle.getTag() != null && (boolean) checkCircle.getTag();
                boolean newState = !currentlyFilled;

                updateCheckVisual(checkCircle, newState);
                checkCircle.setTag(newState);

                // PERBAIKAN: Update progress dengan menghitung semua check circles
                updateHabitProgressFromChecks(habitNumber, habitIndex);
            } catch (Exception e) {
                Log.e("MainActivity", "❌ Error updating check circle", e);
            }
        });

        return checkCircle;
    }

    // PERBAIKAN: Method update check visual dengan warna konsisten #F8CC9F
    private void updateCheckVisual(ImageView check, boolean isCompleted) {
        try {
            if (isCompleted) {
                check.setImageResource(R.drawable.ic_check_circle_filled);
                check.setColorFilter(ContextCompat.getColor(this, R.color.check_circle_color));
            } else {
                check.setImageResource(R.drawable.ic_check_circle_outline);
                check.setColorFilter(ContextCompat.getColor(this, R.color.check_circle_color));
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating check visual", e);
        }
    }

    // PERBAIKAN: Method untuk update progress berdasarkan semua check circles
    private void updateHabitProgressFromChecks(int habitNumber, int habitIndex) {
        try {
            List<Habit> currentHabits = getCurrentHabits();
            if (habitIndex < currentHabits.size()) {
                Habit habit = currentHabits.get(habitIndex);

                // Calculate new completed count berdasarkan SEMUA check circles
                int newCompleted = 0;
                com.google.android.flexbox.FlexboxLayout container = getCheckContainer(habitNumber);

                // PERBAIKAN: Simpan state check circles ke HabitDataManager
                String habitKey = dataManager.getHabitKey(currentTab, habitIndex);
                boolean[] currentStates = new boolean[container.getChildCount()];

                for (int i = 0; i < container.getChildCount(); i++) {
                    ImageView check = (ImageView) container.getChildAt(i);
                    boolean isChecked = check.getTag() != null && (boolean) check.getTag();
                    currentStates[i] = isChecked;
                    if (isChecked) {
                        newCompleted++;
                    }
                }

                // PERBAIKAN: Simpan state ke HabitDataManager untuk sinkronisasi
                dataManager.saveCheckCircleState(habitKey, currentStates);

                // PERBAIKAN: Pastikan completed tidak melebihi total
                if (newCompleted > habit.getTotal()) {
                    newCompleted = habit.getTotal();
                }

                // Update habit dengan completed count yang baru
                habit.setCompleted(newCompleted);
                dataManager.updateHabitProgress(currentTab, habitIndex, newCompleted);

                // Update UI
                updateHabitUI(habitNumber, habit);
                updateCircleChartForCurrentTab();

                // PERBAIKAN: Panggil listener untuk refresh data
                if (habitsChangedListener != null) {
                    habitsChangedListener.onHabitsChanged();
                }

                Log.d("MainActivity", "✅ Updated progress: " + habit.getTitle() + " = " + newCompleted + "/" + habit.getTotal());
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating habit progress", e);
        }
    }

    // PERBAIKAN: Update return type untuk getCheckContainer
    private com.google.android.flexbox.FlexboxLayout getCheckContainer(int habitNumber) {
        if (habitNumber == 1) {
            return checksContainerHabit1;
        } else if (habitNumber == 2) {
            return checksContainerHabit2;
        } else if (habitNumber == 3) {
            return checksContainerHabit3;
        } else {
            return checksContainerHabit1;
        }
    }

    private void updateHabitUI(int habitNumber, Habit habit) {
        try {
            ProgressBar progressBar;
            TextView percentageText;
            TextView completedCountText;

            if (habitNumber == 1) {
                progressBar = progressHabit1;
                percentageText = percentageHabit1;
                completedCountText = completedCountHabit1;
            } else if (habitNumber == 2) {
                progressBar = progressHabit2;
                percentageText = percentageHabit2;
                completedCountText = completedCountHabit2;
            } else if (habitNumber == 3) {
                progressBar = progressHabit3;
                percentageText = percentageHabit3;
                completedCountText = completedCountHabit3;
            } else {
                progressBar = progressHabit1;
                percentageText = percentageHabit1;
                completedCountText = completedCountHabit1;
            }

            if (progressBar != null) {
                progressBar.setProgress(habit.getProgressPercentage());

                // Update progress bar color berdasarkan kategori
                int colorRes = getColorResForCategory(habit.getCategory());
                updateProgressBarColor(progressBar, colorRes);
            }

            // Update percentage text color
            if (percentageText != null) {
                int colorRes = getColorResForCategory(habit.getCategory());
                percentageText.setTextColor(ContextCompat.getColor(this, colorRes));
            }

            // Update completed count text
            if (completedCountText != null) {
                completedCountText.setText(getString(R.string.completes_format, habit.getCompleted(), habit.getTotal()));
            }
            if (percentageText != null) {
                percentageText.setText(getString(R.string.percentage_simple, habit.getProgressPercentage()));
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating habit UI", e);
        }
    }

    private void hideHabit1() {
        try {
            if (habitCard1 != null) {
                habitCard1.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error hiding habit 1", e);
        }
    }

    private void hideHabit2() {
        try {
            if (habitCard2 != null) {
                habitCard2.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error hiding habit 2", e);
        }
    }

    private void hideHabit3() {
        try {
            if (habitCard3 != null) {
                habitCard3.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error hiding habit 3", e);
        }
    }

    private void updateHabitText(int habitNumber, int completed, int total) {
        try {
            TextView completedCount, percentageText;

            if (habitNumber == 1) {
                completedCount = completedCountHabit1;
                percentageText = percentageHabit1;
            } else if (habitNumber == 2) {
                completedCount = completedCountHabit2;
                percentageText = percentageHabit2;
            } else if (habitNumber == 3) {
                completedCount = completedCountHabit3;
                percentageText = percentageHabit3;
            } else {
                return;
            }

            if (completedCount != null) {
                completedCount.setText(getString(R.string.completes_format, completed, total));
            }
            if (percentageText != null) {
                percentageText.setText(getString(R.string.percentage_simple, total > 0 ? (completed * 100) / total : 0));
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating habit text", e);
        }
    }

    private void setupClickListeners() {
        // Add Habit Button
        if (cardAddHabit != null) {
            cardAddHabit.setOnClickListener(v -> {
                v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(100)
                        .withEndAction(() -> {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(100).start();
                            navigateToAddHabit();
                        }).start();
            });
        }

        // See All Button
        if (textSeeAll != null) {
            textSeeAll.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, AllHabitsActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            });
        }
    }

    private void setupTabListeners() {
        View.OnClickListener tabClickListener = v -> {
            try {
                TextView selectedTab = (TextView) v;
                String tabName = "";

                int viewId = v.getId();
                if (viewId == R.id.tabDaily) {
                    tabName = "daily";
                } else if (viewId == R.id.tabWeekly) {
                    tabName = "weekly";
                } else if (viewId == R.id.tabMonthly) {
                    tabName = "monthly";
                } else if (viewId == R.id.tabYearly) {
                    tabName = "yearly";
                }

                Log.d("MainActivity", "🔄 Tab clicked: " + tabName);
                showHabitsForTab(tabName);
            } catch (Exception e) {
                Log.e("MainActivity", "❌ Error in tab click listener", e);
            }
        };

        if (tabDaily != null) tabDaily.setOnClickListener(tabClickListener);
        if (tabWeekly != null) tabWeekly.setOnClickListener(tabClickListener);
        if (tabMonthly != null) tabMonthly.setOnClickListener(tabClickListener);
        if (tabYearly != null) tabYearly.setOnClickListener(tabClickListener);
    }

    private List<Habit> getCurrentHabits() {
        try {
            if (dataManager == null) {
                dataManager = HabitDataManager.getInstance();
            }

            List<Habit> habits;
            switch (currentTab) {
                case "weekly":
                    habits = dataManager.getWeeklyHabits();
                    break;
                case "monthly":
                    habits = dataManager.getMonthlyHabits();
                    break;
                case "yearly":
                    habits = dataManager.getYearlyHabits();
                    break;
                default:
                    habits = dataManager.getDailyHabits();
                    break;
            }

            Log.d("MainActivity", "📊 Current habits for " + currentTab + ": " + habits.size() + " habits");
            return habits;
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error getting current habits", e);
            return new java.util.ArrayList<>();
        }
    }

    private void updateCircleChartForCurrentTab() {
        try {
            List<Habit> habits = getCurrentHabits();

            int totalChecks = 0;
            int completedChecks = 0;

            for (Habit habit : habits) {
                totalChecks += habit.getTotal();
                completedChecks += habit.getCompleted();
            }

            updateProgress(completedChecks, totalChecks);
            Log.d("MainActivity", "📈 Circle chart updated: " + completedChecks + "/" + totalChecks);
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating circle chart", e);
        }
    }

    // PERBAIKAN: Method selectTab dengan warna yang benar
    private void selectTab(TextView selectedTab) {
        try {
            // Reset all tabs
            TextView[] tabs = {tabDaily, tabWeekly, tabMonthly, tabYearly};
            int unselectedTextColor = ContextCompat.getColor(this, R.color.tab_unselected_text);
            int selectedTextColor = ContextCompat.getColor(this, R.color.tab_selected_text);

            for (TextView tab : tabs) {
                if (tab != null) {
                    tab.setBackgroundResource(R.drawable.tab_background);
                    tab.setTextColor(unselectedTextColor);
                }
            }

            // Set selected tab
            if (selectedTab != null) {
                selectedTab.setBackgroundResource(R.drawable.tab_background_selected);
                selectedTab.setTextColor(selectedTextColor);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error selecting tab", e);
        }
    }

    private void navigateToAddHabit() {
        try {
            Log.d("MainActivity", "➡️ Navigating to AddHabitActivity");
            Intent intent = new Intent(MainActivity.this, AddHabitActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error navigating to AddHabit", e);
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // PERBAIKAN BESAR: Method openHabitDetail dengan error handling yang lebih robust
    private void openHabitDetail(String frequency, int habitIndex) {
        try {
            // PERBAIKAN: Pastikan data manager terinisialisasi
            if (dataManager == null) {
                dataManager = HabitDataManager.getInstance();
            }

            // VALIDASI DASAR
            if (frequency == null || frequency.isEmpty()) {
                Toast.makeText(this, "Error: Frequency is null", Toast.LENGTH_SHORT).show();
                return;
            }

            // DAPATKAN HABIT LIST dengan method yang aman
            List<Habit> habits = getCurrentHabits();

            // VALIDASI INDEX
            if (habitIndex < 0 || habitIndex >= habits.size()) {
                Toast.makeText(this,
                        "No habit found at position " + (habitIndex + 1),
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Dapatkan habit untuk validasi tambahan
            Habit habit = habits.get(habitIndex);
            if (habit == null) {
                Toast.makeText(this, "Error: Habit data is null", Toast.LENGTH_SHORT).show();
                return;
            }

            // BUAT INTENT
            Intent intent = new Intent(MainActivity.this, HabitDetailActivity.class);
            intent.putExtra("HABIT_FREQUENCY", frequency);
            intent.putExtra("HABIT_INDEX", habitIndex);

            Log.d("MainActivity", "➡️ Opening habit detail: " + habit.getTitle() +
                    " [" + frequency + "][" + habitIndex + "]");

            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error in openHabitDetail", e);
            Toast.makeText(this, "Error opening habit: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void updateProgress(int completed, int total) {
        try {
            int progress = total > 0 ? (completed * 100) / total : 0;
            if (textProgressPercentage != null) {
                textProgressPercentage.setText(getString(R.string.percentage_format, progress));
            }
            if (textCompletedCount != null) {
                textCompletedCount.setText(getString(R.string.completed_count_format, completed, total));
            }
            if (circularProgress != null) {
                circularProgress.setProgress(progress);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating progress", e);
        }
    }

    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }

    private int getColorResForCategory(String category) {
        if (category == null) return R.color.cat_waste;

        switch (category) {
            case "Waste Reduction":
                return R.color.cat_waste;
            case "Water Conservation":
                return R.color.cat_water;
            case "Energy Saving":
                return R.color.cat_energy;
            case "Food Sustainability":
                return R.color.cat_food;
            case "Transportation":
                return R.color.cat_transport;
            case "Shopping":
                return R.color.cat_shopping;
            default:
                return R.color.cat_waste;
        }
    }

    private void updateProgressBarColor(ProgressBar progressBar, int colorRes) {
        try {
            if (progressBar == null) return;

            // Coba update progress drawable secara langsung
            progressBar.getProgressDrawable().setColorFilter(
                    ContextCompat.getColor(this, colorRes),
                    android.graphics.PorterDuff.Mode.SRC_IN
            );
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error updating progress bar color", e);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("MainActivity", "🔄 MainActivity onResume");
        refreshHabitData();
    }

    private void refreshHabitData() {
        try {
            Log.d("MainActivity", "🔄 Refreshing habit data for tab: " + currentTab);
            showHabitsForTab(currentTab);
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error refreshing habit data", e);
        }
    }

    private void setupFooter() {
        try {
            setFooterActive("home");

            View footerHome = findViewById(R.id.footer_home);
            View footerHabits = findViewById(R.id.footer_habits);
            View footerProfile = findViewById(R.id.footer_profile);

            if (footerHome != null) {
                footerHome.setOnClickListener(v -> {
                    // Already on home, just refresh
                    refreshHabitData();
                    Toast.makeText(this, "Refreshing...", Toast.LENGTH_SHORT).show();
                });
            }

            if (footerHabits != null) {
                footerHabits.setOnClickListener(v -> {
                    Log.d("MainActivity", "➡️ Navigating to AllHabitsActivity");
                    Intent intent = new Intent(MainActivity.this, AllHabitsActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
            }

            if (footerProfile != null) {
                footerProfile.setOnClickListener(v -> {
                    Log.d("MainActivity", "➡️ Navigating to ProfileActivity");
                    Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                    startActivity(intent);
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                });
            }

            Log.d("MainActivity", "✅ Footer setup completed");
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error setting up footer", e);
        }
    }

    private void setFooterActive(String activeTab) {
        try {
            int inactiveColor = ContextCompat.getColor(this, R.color.footer_inactive);
            int activeColor = ContextCompat.getColor(this, R.color.footer_active);

            ImageView iconHome = findViewById(R.id.icon_home);
            ImageView iconHabits = findViewById(R.id.icon_habits);
            ImageView iconProfile = findViewById(R.id.icon_profile);

            if (iconHome != null) {
                iconHome.setColorFilter(activeTab.equals("home") ? activeColor : inactiveColor);
            }
            if (iconHabits != null) {
                iconHabits.setColorFilter(activeTab.equals("habits") ? activeColor : inactiveColor);
            }
            if (iconProfile != null) {
                iconProfile.setColorFilter(activeTab.equals("profile") ? activeColor : inactiveColor);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "❌ Error setting footer active", e);
        }
    }

    // PERBAIKAN: Update method onHabitsChanged untuk memastikan check states konsisten
    @Override
    public void onHabitsChanged() {
        runOnUiThread(() -> {
            try {
                Log.d("MainActivity", "🔄 onHabitsChanged - Ensuring check states consistency");

                // PERBAIKAN: Pastikan check states konsisten sebelum refresh
                dataManager.ensureCheckStatesConsistency();

                Log.d("MainActivity", "🔄 onHabitsChanged - Refreshing UI");
                refreshHabitData();
            } catch (Exception e) {
                Log.e("MainActivity", "❌ Error in onHabitsChanged", e);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // PERBAIKAN: Hapus listener untuk menghindari memory leak
        if (dataManager != null) {
            dataManager.setOnHabitsChangedListener(null);
        }
        Log.d("MainActivity", "🔚 MainActivity destroyed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("MainActivity", "⏸️ MainActivity paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("MainActivity", "🛑 MainActivity stopped");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("MainActivity", "▶️ MainActivity started");
    }
}