package com.example.ecohabit1;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity {

    private TextView txtLanguage, txtEnglish, txtContactHelp;
    private Switch switchNotifications;

    // Tambahkan variabel untuk statistics
    private TextView textCompletionPercentage, textHabitsCount;

    private HabitDataManager dataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        // Inisialisasi window insets untuk edge-to-edge
        View rootView = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(rootView, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dataManager = HabitDataManager.getInstance();

        initializeViews();
        setupClickListeners();
        setupFooter();
        updateStatistics();
    }

    private void initializeViews() {
        txtLanguage = findViewById(R.id.txt_language);
        txtEnglish = findViewById(R.id.txt_english);
        txtContactHelp = findViewById(R.id.txt_contact_help);
        switchNotifications = findViewById(R.id.switch_notifications);

        // Inisialisasi views untuk statistics
        textCompletionPercentage = findViewById(R.id.textCompletionPercentage);
        textHabitsCount = findViewById(R.id.textHabitsCount);
    }

    private void setupClickListeners() {
        // Language option
        txtLanguage.setOnClickListener(v -> {
            Toast.makeText(this, "Language option clicked", Toast.LENGTH_SHORT).show();
        });

        txtEnglish.setOnClickListener(v -> {
            Toast.makeText(this, "Language option clicked", Toast.LENGTH_SHORT).show();
        });

        // Contact & Help option
        txtContactHelp.setOnClickListener(v -> {
            Toast.makeText(this, "Contact & Help option clicked", Toast.LENGTH_SHORT).show();
        });

        // Notifications switch
        switchNotifications.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Toast.makeText(ProfileActivity.this, "Notifications enabled", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProfileActivity.this, "Notifications disabled", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void updateStatistics() {
        // Ambil data dari HabitDataManager
        int totalHabits = dataManager.getTotalHabitsCount();
        int completionPercentage = dataManager.getOverallCompletionPercentage();

        // Update UI dengan data real
        textHabitsCount.setText(String.valueOf(totalHabits));
        textCompletionPercentage.setText(String.format("%d%%", completionPercentage));
    }

    private void setupFooter() {
        // Set "profile" as active in footer
        setFooterActive("profile");

        // Set click listeners for footer
        findViewById(R.id.footer_home).setOnClickListener(v -> {
            // Navigate to MainActivity
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
        });

        findViewById(R.id.footer_habits).setOnClickListener(v -> {
            // Navigate to AllHabitsActivity
            Intent intent = new Intent(ProfileActivity.this, AllHabitsActivity.class);
            startActivity(intent);
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        });

        findViewById(R.id.footer_profile).setOnClickListener(v -> {
            // Already on profile page, do nothing
            Toast.makeText(this, "Already on Profile", Toast.LENGTH_SHORT).show();
        });
    }

    private void setFooterActive(String activeTab) {
        int inactiveColor = ContextCompat.getColor(this, R.color.footer_inactive);
        int activeColor = ContextCompat.getColor(this, R.color.footer_active);

        ImageView iconHome = findViewById(R.id.icon_home);
        ImageView iconHabits = findViewById(R.id.icon_habits);
        ImageView iconProfile = findViewById(R.id.icon_profile);

        if (iconHome != null) {
            iconHome.setColorFilter(activeTab.equals("home") ? activeColor : inactiveColor);
        }
        if (iconHabits != null) {
            iconHabits.setColorFilter(activeTab.equals("habits") ? activeColor : inactiveColor);
        }
        if (iconProfile != null) {
            iconProfile.setColorFilter(activeTab.equals("profile") ? activeColor : inactiveColor);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh footer state dan statistics ketika activity resume
        setFooterActive("profile");
        updateStatistics();
    }
}